import LogoSpace from './assets/LogoSpace.png';
import ImgBg1 from './assets/imgB1.jpg';
import ImgBg2 from './assets/imgB2.jpg';
import ImgBg3 from './assets/imgB3.jpg';
import ImgItemS from './assets/imgItemS.png';
import Cybox1 from './assets/cybox1.jpg';
import Cybox2 from './assets/cybox2.jpg';
import Cybox3 from './assets/cybox3.jpg';
import Cybox4 from './assets/cybox4.jpg';
import Cybox5 from './assets/cybox5.jpg';
import Cybox6 from './assets/cybox6.jpg';
import Cybox7 from './assets/cybox7.jpg';
import BgMask from './assets/bgmask.png';
import Team1 from './assets/team1.png';
import Team2 from './assets/team2.png';
import Team3 from './assets/team3.png';
import Team4 from './assets/team4.png';
import Blog1 from './assets/blog1.jpg';
import Blog2 from './assets/blog2.jpg';
import Blog3 from './assets/blog3.jpg';
import Partner1 from './assets/partner1.png'
import Partner2 from './assets/partner2.png'
import Partner3 from './assets/partner3.png'
import FooterImg from './assets/footerimg.png'
import FooterImg2 from './assets/footerimg2.png'
import PostImg1 from './assets/postimg.jpg'
import PostImg2 from './assets/postimg1.jpg'
import PostImg3 from './assets/postimg2.jpg'
import PostImg4 from './assets/postimg3.jpg'
export { 
    LogoSpace, 
    ImgBg1, 
    ImgBg2, 
    ImgBg3, 
    ImgItemS,
    Cybox1,
    Cybox2,
    Cybox3,
    Cybox4,
    Cybox5,
    Cybox6,
    Cybox7,
    BgMask,
    Team1,
    Team2,
    Team3,
    Team4,
    Blog1,
    Blog2,
    Blog3,
    Partner1,
    Partner2,
    Partner3,
    FooterImg,
    FooterImg2,
    PostImg1,
    PostImg2,
    PostImg3,
    PostImg4
};