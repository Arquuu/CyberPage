import { Link } from 'react-router-dom';
import styled, {createGlobalStyle, css} from 'styled-components';
import { motion } from 'framer-motion';
export const GlobalStyle = createGlobalStyle`

*{
    padding: 0;
    margin: 0;
    box-sizing: border-box;
    font-family: ${({theme}) => theme.font.primaryFont};
}

body{
    background-color: ${({theme}) => theme.colors.darkBackground};
}

a{
    text-decoration: none;
}
h1, h2, h3, h4, h5, h6 {
    font-family: ${({theme}) => theme.font.primaryFont};
}
`

export const NavBar = styled(motion.div)`
    position: absolute;
    width: 100%;
    background-color: transparent;
    display: flex;
    height: 80px;
    z-index: 999;

    ${props => props.isActiveNav && css`
    background-color: ${({theme}) => theme.colors.lightBackground};
    position: fixed;
    transition: .4s;
    animation: animatea 2s;

    ${({theme}) => theme.media.tablet}{
        position: absolute;
    }

    @keyframes animatea{
        0%{
            opacity: 0;
            transform: translateY(-200px);
        }

        100%{
            opacity: 1;
            transform: translateY(0);
        }
    }
    `}

`

export const NavbarContent = styled(motion.div)`
    width: 1440px;
    background-color: transparent;
    display: flex;
    margin: 0 auto;
    justify-content: space-between;
    align-items: center;
    ${({theme}) => theme.media.desktop} {
        padding: 0 4rem;
    }

    ${({theme}) => theme.media.mobile} {
        padding: 0 1rem;
    }

`

export const Logo = styled.img`
    max-width: 150px;
    height: 100%;
`

export const MenuList = styled.div`
    display: flex;
    align-items: center;
    justify-content: space-between;
    text-transform: uppercase;
    font-weight: 700;
    font-size: 1rem;
    width: max-content;
    ${({theme}) => theme.media.tablet} {
        display: none;
    }
`

export const Links = styled(Link)`
    display: flex;
    margin-right: ${props => props.menuDesktop ? '2rem' : '0'};
    color: ${({theme}) => theme.colors.white};
    transition: .4s;

    &:hover{
        color: ${({theme}) => theme.colors.green};
    }

    ${({theme}) => theme.media.tablet}{
        &:hover{

        color: ${({theme}) => theme.colors.white};
    }

    }
`

export const MobileMenu = styled(motion.div)`
    width: max-content;
    color: ${({theme}) => theme.colors.white};
    font-size: 2rem;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    transition: .4s;
    position: relative;
    display: none;
    &:hover{
        color: ${({theme}) => theme.colors.green};
    }

    ${({theme}) => theme.media.tablet} {
        display: flex;
    }

`

export const MenuMobileList = styled(motion.div)`
    position: absolute;
    top: 50px;
    right: 0;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    justify-content: flex-end;
    text-align: right;
    height: max-content;
    width: max-content;
    padding: 1rem;
    background-color: ${({theme}) => theme.colors.green};
    
`


export const Footer = styled(motion.div)`
    width: 100%;
    background-color: ${({theme}) => theme.colors.lightBackground};
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    position: relative;

`

export const FooterSocial = styled(motion.div)`
    width: 200px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 4rem 0 2rem 0;
`

export const FooterIcon = styled(motion.div)`
    color: ${({theme}) => theme.colors.white};
    font-size: 1.5rem;
    cursor: pointer;
    transition: .4s;

    &:hover{
        color: ${({theme}) => theme.colors.green}

    }
`

export const FooterTextContainer = styled(motion.div)`
    max-width: 1000px;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    text-align: center;

    ${({theme}) => theme.media.tablet}{
        padding: 2rem 4rem;
    }

    ${({theme}) => theme.media.mobile}{
        padding: 2rem 1rem;
    }
`

export const FooterTitle = styled(motion.h1)`
    color: ${({theme}) => theme.colors.white};
    letter-spacing: 1px;
    display: flex;
    margin-bottom: 1rem;
    width: 100%;
`

export const FooterDescription = styled(motion.p)`
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    display: block;
`

export const FooterInputs = styled(motion.div)`
    display: flex;
    width: 550px;
    margin-top: 4rem;
    justify-content: center;
    align-items: center;
    

    ${({theme}) => theme.media.tablet}{
        padding: 2rem 4rem;
        width: 100%;
    }

    ${({theme}) => theme.media.mobile}{
        padding: 2rem 1rem;
    }
`

export const FooterInput = styled(motion.input)`
    width: 100%;
    background-color: transparent;
    outline: none;
    border: 2px solid ${({theme}) => theme.colors.green};
    margin-right: 1rem;
    padding: 1rem 1.5rem;
    font-family: ${({theme}) => theme.font.secondFont};
    color: ${({theme}) => theme.colors.white};
    letter-spacing: 1px;
`

export const FooterLinks = styled(motion.div)`
    display: flex;
    justify-content: center;
    align-items: center;
    width: 100%;
    margin-top: 5rem;
    padding: 2rem 1rem;
    border-top: 2px solid ${({theme}) => theme.colors.green};
    background-color: ${({theme}) => theme.colors.darkGreen};
    height: 80px;
`

export const FooterImg1 = styled(motion.img)`
    position: absolute;
    top: 0;
    left: 10%;
`

export const FooterImg3 = styled(motion.img)`
    position: absolute;
    bottom: 80px;
    right: 10%;
    `

export const MobileFix = styled(motion.div)`
    width: 80%;
    margin: 0 auto;
    left: 50%;
    transform: translateX(${props => props.isActive === 'Active' ? '-50%' : '100%'});
    position: fixed;
    bottom: 5%;
    display: none;
    justify-content: space-around;
    align-items: center;
    height: 60px;
    border-radius: 20px;
    backdrop-filter: blur(50px);
    z-index: 999;
    transition: .4s;

    ${({theme}) => theme.media.tablet} {
        display: flex;
        width: 50%;
    }
    ${({theme}) => theme.media.mobile} {
        display: flex;
        width: 80%;
    }

`

export const MenuIcon = styled(motion.div)`
    font-size: 1.5rem;
    color: ${({theme}) => theme.colors.white};
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 1rem;
    transition: .4s;
    border-radius: 50%;

    ${props => props.isActive && css`
        transform: translateY(-25px);
        background-color: ${({theme}) => theme.colors.green};
        padding: 1rem;
        border-radius: 50%;
        color: ${({theme}) => theme.colors.white};
    `}
`

export const ButtonTop = styled(motion.div)`
    position: fixed;
    display: flex;
    width: 50px;
    height: 50px;
    justify-content: center;
    align-items: center;
    bottom: 50px;
    right: 50px;
    background-color: ${({theme}) => theme.colors.green};
    border: 2px solid ${({theme}) => theme.colors.green};
    color: ${({theme}) => theme.colors.white};
    z-index: 999;
    font-size: 1.5rem;
    transition: .4s;
    cursor: pointer;
    transform: translateY(-300px);
    opacity: 0;

    ${props => props.isActive && css`
    transform: translateY(0px);
    opacity: 1;
    `}
    
    &:hover{
        background-color: transparent;
    }

    ${({theme}) => theme.media.tablet}{
        display: none;
    }

`


export const aHref = styled(motion.div)`


`