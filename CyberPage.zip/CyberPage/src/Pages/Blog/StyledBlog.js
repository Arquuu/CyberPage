import styled from "styled-components";
import { motion } from "framer-motion";

export const BlogContent = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    padding: 4rem 0;
    overflow: hidden;

    ${({theme}) => theme.media.desktop}{
        padding: 4rem;
    }

    ${({theme}) => theme.media.tablet}{
        flex-direction: column;
    }

    ${({theme}) => theme.media.mobile}{
        padding: 4rem 1rem;
    }

`
export const BlogLeftCol = styled(motion.div)`
    max-width: 70%;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;
    margin-right: 2rem;
    ${({theme}) => theme.media.tablet}{
        max-width: 100%;
        margin-right: 0;
    }

`

export const BlogRightCol = styled(motion.div)`
    max-width: 30%;
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;
    margin-left: 2rem;

    ${({theme}) => theme.media.tablet}{
        max-width: 100%;
        width: 100%;
        margin-left: 0;
        margin-top: 4rem;
    }

`

export const PostList = styled(motion.div)`
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;

`