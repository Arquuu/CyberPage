import React from 'react'
import { Header } from '../Components/importComponents'
import { BlogContent, BlogLeftCol, BlogRightCol, PostList } from './StyledBlog'
import { MainPost, PostItem, PaginationButton, Searcher, Categories, RecentPosts, PopularTags } from '../../Elements/importElements'
const Blog = () => {
  return (
    <div>
      <Header 
      title='BLOG'
      />
      <BlogContent>
        <BlogLeftCol
          initial={{opacity: 0, x:-100}}
          whileInView={{opacity: 1, x:0}}
          viewport={{once: true}}
          transition={{duration: .4}}
        >
          <MainPost />
          <PostList>
            <PostItem />
          </PostList>
          <PaginationButton />
        </BlogLeftCol>
        <BlogRightCol
        initial={{opacity: 0, x:100}}
        whileInView={{opacity: 1, x:0}}
        viewport={{once: true}}
        transition={{duration: .4}}
        >
          <Searcher />
          <Categories />
          <RecentPosts />
          <PopularTags />
        </BlogRightCol>

      </BlogContent>

    </div>
  )
}

export default Blog