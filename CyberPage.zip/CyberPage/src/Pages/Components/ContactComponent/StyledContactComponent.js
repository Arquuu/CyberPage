import styled from "styled-components";
import { motion } from "framer-motion";

export const ContactContent = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;
    display: flex;
    padding: 4rem 0 6rem 0;
    overflow: hidden;

    ${({theme}) => theme.media.desktop}{
        padding: 4rem 4rem 6rem 4rem;
    }

    ${({theme}) => theme.media.tablet}{
        flex-direction: column;
    }

    ${({theme}) => theme.media.tablet}{
        padding: 4rem 1rem 6rem 1rem;
    }

`
export const ContactLeft = styled(motion.div)`
    width: 50%;
    padding-right: 2rem;

    ${({theme}) => theme.media.tablet}{
        width: 100%;
        padding-right: 0;
        margin-bottom: 5rem;
    }
`
export const ContactRight = styled(motion.div)`
    width: 50%;
    padding-left: 2rem;

    ${({theme}) => theme.media.tablet}{
        width: 100%;
        padding-left: 0;
    }
`