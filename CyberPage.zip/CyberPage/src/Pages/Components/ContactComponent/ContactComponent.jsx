import React from 'react'
import { ContactContent, ContactLeft, ContactRight} from './StyledContactComponent'
import { ContactForm, ContactMap } from '../../../Elements/importElements'

const ContactComponent = () => {
  return (
    <ContactContent>
      <ContactLeft
        initial={{opacity: 0, y:-100}}
        whileInView={{opacity: 1, y:0}}
        viewport={{once: true}}
        transition={{duration: .4}}
      >
        <ContactForm />
      </ContactLeft>
      <ContactRight
        initial={{opacity: 0, y:100}}
        whileInView={{opacity: 1, y:0}}
        viewport={{once: true}}
        transition={{duration: .4}}
      >
        <ContactMap />
      </ContactRight>
    </ContactContent>
  )
}

export default ContactComponent