import React, {useState} from 'react'
import { HeadingSectionCenter } from '../../../Elements/importElements'
import { RoadmapElement, List, ListItem, TitleItem, RoadContent, RoadItem, RoadColumns, RoadLeft, RoadRight } from './StyledRoadmap'
const ItemContentLeft = [
    {
        id:1,
        title:'Q2 2022',
        list: {
            pkt1: 'Aenean tempor',
            pkt2: 'Fusce arcu maecenas',
            pkt3: 'Fusce arcu maecenas',
            pkt4: 'Risus eu metus1',
        }
    },
    {
        id:2,
        title:'Q4 2022',
        list: {
            pkt1: 'Aenean tempor',
            pkt2: 'Fusce arcu maecenas',
            pkt3: 'Fusce arcu maecenas',
            pkt4: 'Risus eu metus2',
        }
    },
    {
        id:3,
        title:'Q3 2022',
        list: {
            pkt1: 'Aenean tempor',
            pkt2: 'Fusce arcu maecenas',
            pkt3: 'Fusce arcu maecenas',
            pkt4: 'Risus eu metus',
        }
    },
]

const ItemContentRight = [
    {
        id:4,
        title:'Q2 2022',
        list: {
            pkt1: 'Aenean tempor',
            pkt2: 'Fusce arcu maecenas',
            pkt3: 'Fusce arcu maecenas',
            pkt4: 'Risus eu metus1',
        }
    },
    {
        id:5,
        title:'Q4 2022',
        list: {
            pkt1: 'Aenean tempor',
            pkt2: 'Fusce arcu maecenas',
            pkt3: 'Fusce arcu maecenas',
            pkt4: 'Risus eu metus2',
        }
    },
]

const Roadmap = () => {
    const [activeItem, setActiveItem] = useState(0);
  return (

    <RoadmapElement>
        <RoadContent>
            <HeadingSectionCenter
            sectionName= 'Roadmap'
            title='SpaceIT TIMELINe'/>
            <RoadColumns>
                <RoadLeft>
                {ItemContentLeft.map((props) => (
                    <RoadItem
                    initial={{opacity: 0, x: -200}}
                    whileInView={{opacity:1, x: 0}}
                    transition={{duration: .5}}
                    viewport={{once: true}}
                    onClick={() => setActiveItem(props.id)}
                    isActive={activeItem === props.id ? 'Active' : ''}
                    >
                    <TitleItem>{props.title}</TitleItem>
                    <List>
                        <ListItem>{props.list.pkt1}</ListItem>
                        <ListItem>{props.list.pkt2}</ListItem>
                        <ListItem>{props.list.pkt3}</ListItem>
                        <ListItem>{props.list.pkt4}</ListItem>
                    </List>
                    </RoadItem>

                ))}
                </RoadLeft>

                <RoadRight>
                {ItemContentRight.map((props) => (
                    <RoadItem
                    initial={{opacity: 0, x: 200}}
                    whileInView={{opacity:1, x: 0}}
                    transition={{duration: .5}}
                    viewport={{once: true}}
                    onClick={() => setActiveItem(props.id)}
                    isActive={activeItem === props.id ? 'Active' : ''}
                    >
                    <TitleItem>{props.title}</TitleItem>
                    <List>
                        <ListItem>{props.list.pkt1}</ListItem>
                        <ListItem>{props.list.pkt2}</ListItem>
                        <ListItem>{props.list.pkt3}</ListItem>
                        <ListItem>{props.list.pkt4}</ListItem>
                    </List>
                    </RoadItem>

                ))}
                </RoadRight>
            </RoadColumns>
        </RoadContent>
    </RoadmapElement>

  )
}

export default Roadmap