import { motion } from "framer-motion";
import styled, {css} from "styled-components";
import { BgMask } from "../../../importImages";
const RoadmapElement = styled(motion.div)`
    width: 100%;
    height: max-content;
    margin: 4rem auto;
    display: flex;
    flex-direction: column;
    background-image: url(${BgMask});
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    overflow: hidden;
`

const RoadContent = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;

    ${({theme}) => theme.media.tablet} {
        width: 100%;
    }

`
const RoadColumns = styled(motion.div)`
    width: 100%;
    height: 1000px;
    display: flex;
    flex-direction: row;

    ${({theme}) => theme.media.tablet} {
        height: 100%;
        flex-direction: column;
    }
`

const RoadLeft = styled(motion.div)`
    display: flex;
    width: 100%;
    height: 100%;
    border-right: 2px solid${({theme}) => theme.colors.textColor};
    flex-direction: column;
    align-items: center;
    justify-content: space-between;

    ${({theme}) => theme.media.tablet} {
        border-right: none ;
        border-left: 2px solid${({theme}) => theme.colors.textColor};;
        padding: 1rem 4rem;
    }

    ${({theme}) => theme.media.mobile} {
        padding: 1rem;
    }

`

const RoadRight = styled(motion.div)`
    width: 100%;
    height: 100%;
    align-items: center;
    display: flex;
    flex-direction: column;
    justify-content: space-evenly;

    ${({theme}) => theme.media.tablet} {
        border-right: none ;
        border-left: 2px solid${({theme}) => theme.colors.textColor};
        padding: 1rem 4rem;
    }

    ${({theme}) => theme.media.mobile} {
        padding: 1rem;
    }
`

const RoadItem = styled(motion.div)`
    width: 350px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
    height: auto;
    padding: 1rem 2rem;
    margin: 1rem 3rem;
    background-color: #0e2331;
    border: 2px solid ${({theme}) => theme.colors.darkGreen};
    position: relative;
    transition: .4s;
    cursor: pointer;

    ${({theme}) => theme.media.tablet} {
        padding: 0rem 1rem;
        margin: 1rem 2rem;
        width: 100%;
    }

    ${({theme}) => theme.media.mobile} {
       width: 100%;
    }

    &:hover{
        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};

        :before{
            width: 0%;
        }

        :after{
            width: 0%;
        }
    
    }

    ${props => props.isActive && css`
        :before{
            display: none;
        }
        :after{
            display: none;
        }

        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    
    `}

    &::before{
        content: '';
        position: absolute;
        width: calc(100% - 2rem);
        left: 50%;
        transform: translateX(-50%);
        height: 2px;
        top: -2px;
        background-color: #0e2331;
        transition: .4s;
    }

    &::after{
        content: '';
        position: absolute;
        width: calc(100% - 2rem);
        left: 50%;
        transform: translateX(-50%);
        height: 2px;
        bottom: -2px;
        background-color: #0e2331;
        transition: .4s;
    }
`
const TitleItem = styled(motion.h2)`
    font-size: 2rem;
    font-family: ${({theme}) => theme.font.primaryfont};
    color: ${({theme}) => theme.colors.white};
    margin-bottom: 1rem;
    
`

const List = styled(motion.ul)`
    list-style: none;

`

const ListItem = styled(motion.li)`
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    margin-bottom: 0.5rem;
    font-size: 1rem;

`
export {RoadmapElement, RoadLeft, RoadRight, RoadColumns, RoadContent, RoadItem, ListItem, TitleItem, List}