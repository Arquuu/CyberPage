import React from 'react'
import {HeaderElement, HeaderTitle} from './Styledheader'
const Header = (props) => {
  return (
    <HeaderElement 
    >
        <HeaderTitle
          initial={{opacity: 0, y: -100}}
          animate={{opacity: 1, y: 0}}
        >
            {props.title}
        </HeaderTitle>


    </HeaderElement>
  )
}

export default Header