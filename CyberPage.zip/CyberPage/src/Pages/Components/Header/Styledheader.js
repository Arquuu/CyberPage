import styled from "styled-components";
import { motion } from "framer-motion";
import { ImgBg3 } from "../../../importImages";

const HeaderElement = styled(motion.div)`
    width: 100%;
    height: 300px;
    background-image: url(${ImgBg3});
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 4rem;
    border-bottom: 2px solid ${({theme}) => theme.colors.green};
    overflow: hidden;
`

const HeaderTitle = styled(motion.h1)`
    font-size: 6rem;
    color: ${({theme}) => theme.colors.white};
    text-transform: uppercase;
    letter-spacing: 5px;

    ${({theme}) => theme.media.tablet}{
        font-size: 4rem;

    }
    ${({theme}) => theme.media.mobile}{
        font-size: 3rem;

    }
`

export {
    HeaderElement,
    HeaderTitle
}