import React, { useState } from 'react'
import { Button, HeadingSectionCenter } from '../../../Elements/importElements'
import { Blog1, Blog2, Blog3 } from '../../../importImages'
import { LastBlogElement, ItemsBlog, ItemBlog, ItemBlogCategory, ItemBlogTextContent, ItemBlogData, ItemBlogTitle, ItemBlogDescription, ButtonContent} from './StyledLastBlog'
import "swiper/css";
import { Swiper, SwiperSlide } from "swiper/react";
const LastNews = [
    {
        id:1,
        category: 'Digitalart',
        img: `${Blog1}`,
        date: '20 Jun 2022',
        title: 'NFT Guide: Why They Matter For Music',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor.'
    },
    {
        id:2,
        category: 'Nftartwork',
        img: `${Blog2}`,
        date: '20 Jun 2022',
        title: 'Max Live X Tacnocde Matter NFT Music',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor.'
    },
    {
        id:3,
        category: 'Digitalart',
        img: `${Blog3}`,
        date: '20 Jun 2022',
        title: 'NFT Guide: Why They Matter For Music',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor.'
    },
    {
        id:4,
        category: 'Digitalart',
        img: `${Blog1}`,
        date: '20 Jun 2022',
        title: 'NFT Guide: Why They Matter For Music',
        description: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Lorem ipsum dolor.'
    },
    
]


const LastBlog = () => {
    const [active, setActive] = useState(0);
  return (
    <LastBlogElement
    initial={{opacity: 0}}
    whileInView={{opacity: 1}}
    transition={{duration: 2}}
    viewport={{once: true}}
    >
        <HeadingSectionCenter
        sectionName='Blogs' 
        title='Lastest News'/>
        <ItemsBlog>
        <Swiper
        slidesPerView={`${window.innerWidth < 900 ? 1 : 3}`}
        spaceBetween={30}
        className="mySwiper"
      >
        {LastNews.map((props) =>(
            <SwiperSlide style={{
            backgroundSize: 'cover',
            backgroundRepeat: 'no-repeat',
            backgroundPosition: 'center',
            backgroundImage: `url(${props.img})`
            }}>
                <ItemBlog
                onClick={() => setActive(props.id)}
                isActive={`${props.id === active ? 'Active' : ''}`}>
                    <ItemBlogCategory>{props.category}</ItemBlogCategory>
                    <ItemBlogTextContent>
                        <ItemBlogData>{props.date}</ItemBlogData>
                        <ItemBlogTitle>{props.title}</ItemBlogTitle>
                        <ItemBlogDescription>{props.description}</ItemBlogDescription>
                    </ItemBlogTextContent>
                </ItemBlog>
            </SwiperSlide>
        ))}

        </Swiper>
        </ItemsBlog>
        <ButtonContent>
        <Button 
        text='Explore more'
        link=''
        />
        </ButtonContent>

    </LastBlogElement>
  )
}

export default LastBlog