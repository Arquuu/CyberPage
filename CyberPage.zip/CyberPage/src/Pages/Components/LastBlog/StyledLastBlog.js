import styled, {css} from "styled-components";
import { motion } from "framer-motion";

const LastBlogElement = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;
    padding: 4rem 0;
    overflow: hidden;

    ${({theme}) => theme.media.desktop}{
        padding: 4rem;
    }

    ${({theme}) => theme.media.mobile}{
        padding: 4rem 1rem;
    }

`
const ItemsBlog = styled(motion.div)`
    width: 100%;
    display: flex;
`
const ItemBlog = styled(motion.div)`
    width: 100%;
    min-height: 530px;
    display: flex;
    flex-direction: column;
    position: relative;
    border: 2px solid ${({theme}) => theme.colors.darkGreen};
    transition: .4s;
    cursor: pointer;

    &:hover{
    -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    border: 2px solid ${({theme}) => theme.colors.green};
    }

    ${props => props.isActive && css`

        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    
    `}

`
const ItemBlogCategory = styled(motion.div)`
    background: ${({theme}) => theme.colors.green};
    color: ${({theme}) => theme.colors.white};
    font-family: ${({theme}) => theme.font.secondFont};
    width: max-content;
    padding: 0.5rem 1rem;
    position: absolute;
    top: 20px;
    left: 20px;

`
const ItemBlogTextContent = styled(motion.div)`
    position: absolute;
    bottom: 0;
    backdrop-filter: blur(10px);
`
const ItemBlogData = styled(motion.p)`
    font-family: ${({theme}) => theme.font.secondFont};
    color: ${({theme}) => theme.colors.white};
    display: block;
    padding: 1rem 0rem .5rem 1rem;
`
const ItemBlogTitle = styled(motion.h1)`
    font-family: ${({theme}) => theme.font.primaryFont};
    color: ${({theme}) => theme.colors.white};
    font-size: 1.5rem;
    letter-spacing: 1px;
    padding: 0rem 1rem;
    display: block;

`
const ItemBlogDescription = styled(motion.p)`
    font-family: ${({theme}) => theme.font.secondFont};
    color: ${({theme}) => theme.colors.textColor};
    font-size: 1rem;
    letter-spacing: 1px;
    padding: 1rem;
    display: block;
`


const ButtonContent = styled(motion.div)`
    width: 100%;
    display: flex;
    margin: 3rem 0;
    justify-content: center;
    align-items: center;
`

export {
    LastBlogElement, 
    ItemsBlog,
    ItemBlog,
    ItemBlogCategory,
    ItemBlogTextContent,
    ItemBlogData,
    ItemBlogTitle,
    ItemBlogDescription,
    ButtonContent

}