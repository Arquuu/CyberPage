import React, { useState } from 'react'
import { HeadingSection } from '../../../Elements/importElements'
import { HowWeWorkElement, HowWeWorkItems, HowWeWorkItem, ItemNumber, ItemTitle, ItemDescription, HeadingSectionStyled, ItemContent } from './StyledHowWeWork'


const HowWeWorkContentItem = [

    {
        id: 1,
        title: 'Set up Your Wallet',
        description: 'Arcu morbi sit laoreet semper ultrices maecenas auctor amet. Donec tortor facilisis risus, neque sit aliquet orci, malesuada.'
    },
    {
        id: 2,
        title: 'Buy Your Collection',
        description: 'Arcu morbi sit laoreet semper ultrices maecenas auctor amet. Donec tortor facilisis risus, neque sit aliquet orci, malesuada.'
    },
    {
        id: 3,
        title: "Add Your NFT's",
        description: 'Arcu morbi sit laoreet semper ultrices maecenas auctor amet. Donec tortor facilisis risus, neque sit aliquet orci, malesuada.'
    },
    {
        id: 4,
        title: "Sell Your NFT's",
        description: 'Arcu morbi sit laoreet semper ultrices maecenas auctor amet. Donec tortor facilisis risus, neque sit aliquet orci, malesuada.'
    },
]





const HowWeWork = () => {

    const [active, setActive] = useState(1);

  return (
    <HowWeWorkElement
    >
        <HeadingSectionStyled
        initial={{opacity: 0, x: 200}}
        whileInView={{opacity: 1, x: 0}}
        transition={{duration: 1}}
        viewport={{once: true}}
        >
        <HeadingSection
            sectionName='How we work'
            title='BECOME OUR MEMBER'
            description='Maecenas sit pretium, cras in. In quisque sem id eget. In vel gravida ut adipiscing integer felis.'
         />
        </HeadingSectionStyled>

        <HowWeWorkItems>

            {HowWeWorkContentItem.map((props) => (

                <HowWeWorkItem
                onClick={() => setActive(props.id)}
                isActive={active === props.id ? 'Active' : ''}
                initial={{opacity: 0, rotate: 90}}
                whileInView={{opacity: 1, rotate: 0}}
                transition={{duration: 1}}
                viewport={{once: true}}
                >
                    <ItemContent
                    isActive={active === props.id ? 'Active' : ''}>
                        <ItemNumber>0{props.id}</ItemNumber>
                        <ItemTitle>{props.title}</ItemTitle>
                        <ItemDescription>{props.description}</ItemDescription>
                    </ItemContent>
                </HowWeWorkItem>


            ))}

        </HowWeWorkItems>

    </HowWeWorkElement>
  )
}

export default HowWeWork