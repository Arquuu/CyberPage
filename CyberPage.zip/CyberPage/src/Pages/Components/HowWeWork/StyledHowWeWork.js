import styled, {css} from "styled-components";
import { motion } from "framer-motion";

const HowWeWorkElement = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    padding: 2rem 0;
    overflow: hidden;

    ${({theme}) => theme.media.desktop} {
        padding: 2rem 4rem;
    }

    ${({theme}) => theme.media.mobile} {
        padding: 1rem;
    }
`

const HowWeWorkItems = styled(motion.div)`
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;

    ${({theme}) => theme.media.desktop} {
        flex-wrap: wrap;
    }

    ${({theme}) => theme.media.tablet} {
        flex-direction: column;
    }

`

const HowWeWorkItem = styled(motion.div)`
    max-width: 25%;
    margin-right: 2rem;
    background: rgba(34,183,143,.1);
    padding: 1rem;
    position: relative;
    border: 2px solid ${({theme}) => theme.colors.green};
    cursor: pointer;

    &:last-child{
        margin-right: 0;
    }

    ${({theme}) => theme.media.desktop} {
        width: 49%;
        max-width: 100%;
        margin-right: 0;
        margin-bottom: 2%;
    }

    ${({theme}) => theme.media.tablet} {
        width: 100%;
        margin-bottom: 1rem;
    }

    ${props => props.isActive && css`
        :before{
            display: none;
        }
        :after{
            display: none;
        }

        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    
    `}
    &::before{
        content: '';
        position: absolute;
        width: calc(100% - 2rem);
        left: 50%;
        transform: translateX(-50%);
        height: 2px;
        top: -2px;
        background-color: ${({theme}) => theme.colors.darkGreen};
        transition: .4s;
    }

    &::after{
        content: '';
        position: absolute;
        width: calc(100% - 2rem);
        left: 50%;
        transform: translateX(-50%);
        height: 2px;
        bottom: -2px;
        background-color: ${({theme}) => theme.colors.darkGreen};
        transition: .4s;
    }

    &:hover::before{
        width: 0%;
    }

    &:hover::after{
        width: 0%;
    }

    &:hover{
    -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    }

`

const ItemNumber = styled(motion.h1)`
    position: absolute;
    font-size: 4rem;
    top: 0;
    font-family: ${({theme}) => theme.font.primaryFont};
    font-weight: bold;
    color: ${({theme}) => theme.colors.white};
    opacity: .1;
`

const ItemTitle = styled(motion.h2)`
    font-family: ${({theme})=>theme.font.primaryFont};
    color: ${({theme}) => theme.colors.white};
    letter-spacing: 1px;
    text-transform: capitalize;
    display: block;
    margin-bottom: 1rem;

`

const ItemDescription = styled(motion.p)`
    font-family: ${({theme}) => theme.font.secondFont};
    color: ${({theme}) => theme.colors.textColor};
    line-height: 1.5;

`

const HeadingSectionStyled = styled(motion.div)`
    max-width: 550px;

    @media screen and (max-width: 1000px){
        max-width: 100%;
    }

`

const ItemContent = styled(motion.div)`
    width: 100%;
    height: 100%;

    ${props => props.isActive && css`
        :before{
            display: none;
        }
        :after{
            display: none;
        }
    `}

    &::before{
        content: '';
        position: absolute;
        width: 2px;
        left: -2px;
        height: calc(100% - 2rem);
        top: 50%;
        transform: translateY(-50%);
        background-color: ${({theme}) => theme.colors.darkGreen};
        transition: .4s;
    }

    &::after{
        content: '';
        position: absolute;
        width: 2px;
        right: -2px;
        height: calc(100% - 2rem);
        top: 50%;
        transform: translateY(-50%);
        background-color: ${({theme}) => theme.colors.darkGreen};
        transition: .4s;
    }

    &:hover::before{
        height: 0%;
    }
    &:hover::after{
        height: 0%;
    }

`

export { HowWeWorkElement, HowWeWorkItems , HowWeWorkItem, ItemNumber, ItemTitle, ItemDescription, HeadingSectionStyled, ItemContent}