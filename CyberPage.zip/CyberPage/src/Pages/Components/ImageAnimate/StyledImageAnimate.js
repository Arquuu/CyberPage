import { motion } from "framer-motion";
import styled from "styled-components";

export const ContainerImage = styled(motion.div)`
    width: 100%;
    display: flex;
    margin: 0 auto;
    flex-direction: column;

`
export const Wrapper = styled(motion.div)`
    max-width: 100%;
    display: flex;
    margin: 0 auto;
    overflow: hidden;
`


export const RowUp = styled(motion.div)`
    display: flex;
    width: calc(250px * 14);
    animation: scroll 10s linear infinite;
    transition: .4s;

    &:hover{
        animation-play-state: paused;
    }

    @keyframes scroll {
        0%{
            transform: translateX(0);
        }
        100%{
            transform: translateX(calc(-282px * 7));
        }
    }
`


export const ItemContent = styled(motion.div)`
    max-width: 250px;
    padding: 1rem;
    border: 2px solid ${({theme}) => theme.colors.darkGreen};
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: center;
    user-select: none;
    margin: 0 1rem;
    cursor: pointer;
    transition: .4s;

    &:hover{
        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    }
`

export const ItemImg = styled(motion.img)`
    max-width: calc(250px - 2rem);
    user-select: none;
    pointer-events: none;

`

export const ItemTitle = styled(motion.h4)`
    color: ${({theme}) => theme.colors.white};
    font-family: ${({theme}) => theme.font.primaryFont};
    font-size: 1.5rem;
    line-height: 2;
    text-transform: uppercase;
    display: block;
    margin-top: 1rem;
`
