import { motion } from 'framer-motion'
import React, { useState, useEffect, useRef } from 'react'
import { Cybox1, Cybox2, Cybox3, Cybox4, Cybox5, Cybox6, Cybox7 } from '../../../importImages'
import { ContainerImage, Wrapper, RowUp, ItemContent, ItemImg, ItemTitle } from './StyledImageAnimate'
const itemsContent = [

    {
        id: 1,
        image: `${Cybox1}`
    },
    {
        id: 2,
        image: `${Cybox2}`
    },
    {
        id: 3,
        image: `${Cybox3}`
    },
    {
        id: 4,
        image: `${Cybox4}`
    },
    {
        id: 5,
        image: `${Cybox5}`
    },
    {
        id: 6,
        image: `${Cybox6}`
    },
    {
        id: 7,
        image: `${Cybox7}`
    },
]

const ImageAnimate = () => {

    const [width, setWidth] = useState(0);
    const carousel = useRef();

    useEffect(() =>{

        setWidth(carousel.current.offsetWidth);

    }, [])
  return (
    <>
        <ContainerImage
                ref={carousel}
        >
        <Wrapper>
        <RowUp>
            {itemsContent.map((props) =>(
                <ItemContent>
                    <ItemImg src={props.image} alt='' />
                    <ItemTitle>Cybox #{props.id}</ItemTitle>
                </ItemContent>
            ))}
            
            {itemsContent.map((props) =>(
                <ItemContent>
                    <ItemImg src={props.image} alt='' />
                    <ItemTitle>Cybox #{props.id}</ItemTitle>
                </ItemContent>
            ))}

        </RowUp>
        </Wrapper>
        </ContainerImage>
    
    
    </>
  )
}

export default ImageAnimate