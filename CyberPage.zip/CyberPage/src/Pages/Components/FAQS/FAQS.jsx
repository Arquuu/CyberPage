import React, { useState } from 'react'
import { HeadingSectionCenter } from '../../../Elements/importElements'
import { FAQSElement, FAQItem, FAQSList, FAQTop, FAQTitle, FAQIcon, FAQDescritpion, FAQContainer, FAQDescritpionContainer, HeadFAQStyled } from './StyledFAQS'
import {IoIosArrowDown} from 'react-icons/io'
const FAQContent = [
    {
        id: 1,
        title: 'What Are The NFTs?',
        description: 'Urna vitae erat et lacus, consectetur ac nulla vestibulum lobortis. Nulla dapibus urna volutpat venenatis, risus faucibus.'
    },
    {
        id: 2,
        title: 'How Do I Get NFTs?',
        description: 'Urna vitae erat et lacus, consectetur ac nulla vestibulum lobortis. Nulla dapibus urna volutpat venenatis, risus faucibus.'
    },
    {
        id: 3,
        title: 'How Can We Buy Your NFTs?',
        description: 'Urna vitae erat et lacus, consectetur ac nulla vestibulum lobortis. Nulla dapibus urna volutpat venenatis, risus faucibus.'
    },
    {
        id: 4,
        title: 'Who Are The Team Behind The Project?',
        description: 'Urna vitae erat et lacus, consectetur ac nulla vestibulum lobortis. Nulla dapibus urna volutpat venenatis, risus faucibus.'
    },

]


const FAQS = () => {
    const [active, setActive] = useState('');

  return (
    <FAQSElement>
        <HeadFAQStyled
        initial={{opacity: 0, y: -200}}
        whileInView={{opacity: 1, y: 0}}
        transition={{duration: 1}}
        viewport={{once: true}}
        >
        <HeadingSectionCenter
        sectionName='FAQS'
        title='Looking for answers?'
        />
        </HeadFAQStyled>
        <FAQSList
        initial={{opacity: 0, y: 200}}
        whileInView={{opacity: 1, y: 0}}
        transition={{duration: .8}}
        viewport={{once: true}}
        >
            {FAQContent.map((props) => (
            <FAQItem
            onClick={() => setActive(props.id)}
            isActive ={`${active === props.id ? 'Active' : ''}`}
            >
                <FAQContainer
                isActive ={`${active === props.id ? 'Active' : ''}`}
                >
                    <FAQTop>
                    <FAQTitle>{props.title}</FAQTitle>
                    <FAQIcon
                    isActive ={`${active === props.id ? 'Active' : ''}`}>
                    <IoIosArrowDown /></FAQIcon>                    
                    </FAQTop>
                    <FAQDescritpionContainer
                    isActive ={`${active === props.id ? 'Active' : ''}`}
                    >
                    <FAQDescritpion>
                    {props.description}
                    </FAQDescritpion> 
                    </FAQDescritpionContainer>

                </FAQContainer>
            </FAQItem>

            ))}
        </FAQSList>


    </FAQSElement>
  )
}

export default FAQS