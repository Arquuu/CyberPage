import styled, {css} from "styled-components";
import { motion } from "framer-motion";

const FAQSElement = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;
    padding: 4rem 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;

    ${({theme}) => theme.media.desktop}{
        padding: 4rem;
    }

    ${({theme}) => theme.media.mobile}{
        padding: 4rem 1rem;
    }

    
`

const FAQItem = styled(motion.div)`
    width: 100%;
    margin-bottom: 1rem;
    display: flex;
    flex-direction: column;
    cursor: pointer;
    position: relative;
    transition: .4s;
    background-color: #0e2331;
    border: 2px solid ${({theme}) => theme.colors.green};
    /* overflow: hidden; */


    &::before{
        content: '';
        position: absolute;
        width: calc(100% - 2rem);
        left: 50%;
        transform: translateX(-50%);
        height: 2px;
        top: -2px;
        background-color: #0e2331;
        transition: .4s;
    }

    &::after{
        content: '';
        position: absolute;
        width: calc(100% - 2rem);
        left: 50%;
        transform: translateX(-50%);
        height: 2px;
        bottom: -2px;
        background-color: #0e2331;
        transition: .4s;
    }

    &:hover::before{
        width: 0%;
    }

    &:hover::after{
        width: 0%;
    }

    ${props => props.isActive && css`
        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};

        &:before{
        width: 0%;
        }

        &:after{
        width: 0%;
        }
    `}
`

const FAQSList = styled(motion.div)`
    width: 800px;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    margin: 0 auto;

    ${({theme}) => theme.media.tablet}{
        width: 100%;
    }

`

const FAQTop = styled(motion.div)`
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 1rem;
    border-bottom: 1px solid ${({theme}) => theme.colors.darkGreen};
`

const FAQTitle = styled(motion.h2)`
    display: block;
    color: ${({theme}) => theme.colors.white};
    letter-spacing: 1px;
    font-weight: 500;
`

const FAQIcon = styled(motion.div)`
    font-size: 1.5rem;
    color: ${({theme}) => theme.colors.white};
    display: flex;
    justify-content: center;
    transition: .4s;
    ${props => props.isActive && css`
    
    transform: rotate(-180deg);
    
    `}
`
const FAQDescritpionContainer = styled(motion.div)`
    background-color: #0e2331;
    width: 100%;
    max-height: 0;
    overflow: hidden;

    ${props => props.isActive && css`
    max-height: 100px;
    transition: .8s; 
    opacity: 1;
    `}
`


const FAQDescritpion = styled(motion.p)`
    font-size: 1.1rem;
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    letter-spacing: 1px;
    padding: 1rem;
    line-height: 1.5;

`

const FAQContainer = styled(motion.div)`
    width: 100%;
    height: 100%;
    position: relative;

    &::before{
        content: '';
        position: absolute;
        width: 2px;
        left: -2px;
        height: calc(100% - 2rem);
        top: 50%;
        transform: translateY(-50%);
        background-color: #0e2331;
        transition: .4s;
    }

    &::after{
        content: '';
        position: absolute;
        width: 2px;
        right: -2px;
        height: calc(100% - 2rem);
        top: 50%;
        transform: translateY(-50%);
        background-color: #0e2331;
        transition: .4s;
    }

    &:hover::before{
        height: 0%;
    }
    &:hover::after{
        height: 0%;
    }

    ${props => props.isActive && css`
    
    &:before{
        height: 0%;
    }
    &::after{
        height: 0%;
    }
    `}
    
`

const HeadFAQStyled = styled(motion.div)``

export {
    FAQSElement,
    FAQItem,
    FAQSList,
    FAQTop,
    FAQTitle,
    FAQIcon,
    FAQDescritpion,
    FAQContainer,
    FAQDescritpionContainer,
    HeadFAQStyled
}