import React, { useState } from 'react'
import { HeadingSection, Button } from '../../../Elements/importElements';
import { AboutItemContent, AboutElement, AboutElementLeft, ContentSection, AboutItem, AboutItemTitle, AboutItemDescription } from './StyledAboutComponent'

const itemAboutContent = [
  {
    id: 0,
    title: 'Unique, 1/1 Generated',
    headingDesc: 'Gravida viverra dui aliquet eu tortor lorem et gravida. Sed amet phasellus tellus mauris auctor rhoncus. Malesuada nisl at mauris cursus lorem mattis arcu.'
  },
  {
    id: 1,
    title: '140+ Traits In 16 Categories',
    headingDesc: 'Ornare faucibus urna, netus ut. Ac vulputate ornare donec orci sed gravida senectus. Felis quis morbi vivamus est eget sapien magnis quis.'
  },
  {
    id: 2,
    title: 'Usage Rights Included',
    headingDesc: 'Gravida viverra dui aliquet eu tortor lorem et gravida. Sed amet phasellus tellus mauris auctor rhoncus. Malesuada nisl at mauris cursus lorem mattis arcu.'
  },
]
const AboutComponent = () => {
  const [activeItem, setActiveItem] = useState(0);

  const LinkScrollUp = () => {
    window.scrollTo({
        top: 0,
    })
}
  return (
    <>
        <AboutElement>
            <AboutElementLeft
            initial={{opacity: 0, x:-100}}
            whileInView={{opacity: 1, x:0}}
            viewport={{once: true}}
            transition={{duration: .4}}
            >
            <HeadingSection 
            sectionName='About us'
            title='What is SpaceIT?'
            description='Maecenas sit pretium, cras in. 
            In quisque sem id eget. In vel gravida ut adipiscing integer felis. 
            Id ac non arcu facilisi proin ultrices sed. 
            Id accumsan quam viverra ante in id integer ut. 
            Volutpat lobortis dolor etiam dis interdum tincidunt senectus.'
            />
            <Button
            link=''
            text = 'Get nfts'
            />
            </AboutElementLeft>
            <ContentSection
            initial={{opacity: 0, x:100}}
            whileInView={{opacity: 1, x:0}}
            viewport={{once: true}}
            transition={{duration: .4}}
                        >
            {itemAboutContent.map((props) => (
                <AboutItem
                onClick={() => setActiveItem(props.id)}
                isActive={activeItem === props.id ? 'Active' : '' }
                >
                <AboutItemContent
                onClick={() => setActiveItem(props.id)}
                isActive={activeItem === props.id ? 'Active' : '' }>
                    <AboutItemTitle>
                    {props.title}
                    </AboutItemTitle>
                    <AboutItemDescription>
                    {props.headingDesc}
                    </AboutItemDescription>
                </AboutItemContent>
                </AboutItem>

            ))}
            </ContentSection>
            </AboutElement>    
    </>
  )
}

export default AboutComponent