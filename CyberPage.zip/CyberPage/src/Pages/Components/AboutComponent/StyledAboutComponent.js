import styled, {css} from "styled-components";
import { motion } from "framer-motion";

const AboutElement = styled(motion.div)`
    max-width: 1440px;
    display: flex;
    margin: 0 auto;
    padding: 4rem 0;
    overflow: hidden;

    ${({theme}) => theme.media.desktop} {
        padding:  4rem;
    }

    ${({theme}) => theme.media.tablet} {
        flex-direction: column;
    }

    ${({theme}) => theme.media.mobile} {
        padding: 4rem 1rem;
    }

`

const ContentSection = styled(motion.div)`
    display: flex;
    flex-direction: column;
    width: 50%;
    padding-left: 2rem;

    ${({theme}) => theme.media.tablet} {
        padding-left: 0;
        width: 100%;
        margin-top: 4rem;
    }
`

const AboutItem = styled(motion.div)`
    display: flex;
    flex-direction: column;
    border: 2px solid ${({theme}) => theme.colors.green};
    transition: .4s;
    cursor: pointer;
    margin-bottom: 2rem;
    background-color: rgba(34,183,143,.1);
    position: relative;
    ${props => props.isActive && css`
        :before{
            display: none;
        }
        :after{
            display: none;
        }

        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    
    `}
    &::before{
        content: '';
        position: absolute;
        width: calc(100% - 2rem);
        left: 50%;
        transform: translateX(-50%);
        height: 2px;
        top: -2px;
        background-color: ${({theme}) => theme.colors.darkGreen};
        transition: .4s;
    }

    &::after{
        content: '';
        position: absolute;
        width: calc(100% - 2rem);
        left: 50%;
        transform: translateX(-50%);
        height: 2px;
        bottom: -2px;
        background-color: ${({theme}) => theme.colors.darkGreen};
        transition: .4s;
    }

    &:hover::before{
        width: 0%;
    }

    &:hover::after{
        width: 0%;
    }

    &:hover{
    -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    }
`

const AboutItemTitle = styled(motion.h3)`
    display: block;
    font-size: 1.5rem;
    margin-bottom: 20px;
    text-transform: capitalize;
    line-height: 1.33;
    font-family: ${({theme}) => theme.font.primaryFont};
    color: ${({theme}) => theme.colors.white};
    padding: 2rem 2rem 0 2rem;
`

const AboutItemDescription = styled(motion.p)`
    display: block;
    font-size: 1rem;
    font-family: ${({theme}) => theme.font.secondFont};
    color: ${({theme}) => theme.colors.textColor};
    padding: 0rem 2rem 2rem 2rem;
    line-height: 2;
`

const AboutElementLeft = styled(motion.div)`
    width: 50%;
    display: flex;
    flex-direction: column;
    padding-right: 2rem;

    ${({theme}) => theme.media.tablet} {
        width: 100%;
    }
`
const AboutItemContent = styled(motion.div)`
    width: 100%;
    height: 100%;

    ${props => props.isActive && css`
        :before{
            display: none;
        }
        :after{
            display: none;
        }
    `}

    &::before{
        content: '';
        position: absolute;
        width: 2px;
        left: -2px;
        height: calc(100% - 2rem);
        top: 50%;
        transform: translateY(-50%);
        background-color: ${({theme}) => theme.colors.darkGreen};
        transition: .4s;
    }

    &::after{
        content: '';
        position: absolute;
        width: 2px;
        right: -2px;
        height: calc(100% - 2rem);
        top: 50%;
        transform: translateY(-50%);
        background-color: ${({theme}) => theme.colors.darkGreen};
        transition: .4s;
    }

    &:hover::before{
        height: 0%;
    }
    &:hover::after{
        height: 0%;
    }
`

export { 
    AboutElement, 
    ContentSection, 
    AboutItem, 
    AboutItemTitle,
    AboutItemDescription,
    AboutElementLeft,
    AboutItemContent
}
