import React, {useState} from 'react'
import { HeadingSection } from '../../../Elements/importElements'
import { OurTeamElement, OurTeamCarousel, OurTeamLeft, OurTeamElementContent, TeamItem, TeamImg, TeamTextContent, TeamInfo, TeamName, TeamSocials, TeamSocial } from './StyledOurTeam'
import { Swiper, SwiperSlide } from "swiper/react";
import { Team1, Team2, Team3, Team4 } from '../../../importImages';
import {AiOutlineTwitter} from 'react-icons/ai'
import {FaFacebookF, FaDiscord} from 'react-icons/fa'
import "swiper/css";

const TeamItemContent = [
    {
        id: 1,
        img: `${Team1}`,
        name: 'John Tommy',
        info: 'SEO',
    },
    {
        id: 2,
        img: `${Team2}`,
        name: 'Matt White',
        info: 'CEO',
    },
    {
        id: 3,
        img: `${Team3}`,
        name: 'Danny Bang',
        info: 'Backend Developer',
    },
    {
        id: 4,
        img: `${Team4}`,
        name: 'Ralph Lane',
        info: 'Blockchain Developer',
    }
] 



const OurTeam = () => {

    const [active, setActive] = useState(1);

  return (
    <OurTeamElement>
        <OurTeamElementContent>
        <OurTeamLeft
        initial={{opacity: 0}}
        whileInView={{opacity: 1}}
        transition={{duration: 1}}
        viewport={{once: true}}
        >
            <HeadingSection 
            sectionName='Our Team'
            title='MEET OUR TEAM'
            description='Purus, laoreet dui augue ut euismod. Elementum ante sociis volutpat tellus enim, nisl consectetur mauris. Venenatis congue id quis eget viverra. Vestibulum, justo, euismod congue feugiat eget fames gravida posuere.'

            />
            
        </OurTeamLeft>

        <OurTeamCarousel
        initial={{scale: 0}}
        whileInView={{scale: 1}}
        transition={{duration: 1}}
        viewport={{once: true}}
        >
        <Swiper
        slidesPerView={`${window.innerWidth < 500 ? 1 : 2}`}
        spaceBetween={20}
        className="mySwiper"
        style={{width: '100%'}}
        >
            {TeamItemContent.map((props) => (

                <SwiperSlide>
                    <TeamItem
                    onClick={() => setActive(props.id)}
                    isActive={active === props.id ? 'Active' : ''}>
                        <TeamImg src={props.img} alt='' />
                        <TeamTextContent>
                            <TeamName>{props.name}</TeamName>
                            <TeamInfo>{props.info}</TeamInfo>
                            <TeamSocials>
                                <TeamSocial><AiOutlineTwitter /></TeamSocial>
                                <TeamSocial><FaFacebookF /></TeamSocial>
                                <TeamSocial><FaDiscord /></TeamSocial>
                                </TeamSocials>
                        </TeamTextContent>
                    </TeamItem>
                </SwiperSlide>

            ))}
      </Swiper>



        </OurTeamCarousel>

    </OurTeamElementContent>

    </OurTeamElement>
  )
}

export default OurTeam