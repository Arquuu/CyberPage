import styled, { css } from "styled-components";
import { motion } from "framer-motion";

const OurTeamElement = styled(motion.div)`
    width: 100%;
    background-color: ${({theme}) => theme.colors.lightBackground};
    overflow: hidden;


    ${({theme}) => theme.media.desktop}{
        padding: 4rem;
    }


    ${({theme}) => theme.media.mobile}{
        padding: 1rem;
    }

`

const OurTeamElementContent = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;
    display: flex;
    padding: 4rem 0;

    @media screen and (max-width: 1130px){
        flex-direction: column;
    }

`

const OurTeamCarousel = styled(motion.div)`
    overflow: hidden;
    width: 50%;
    padding-left: 2rem;

    @media screen and (max-width: 1130px){
       width: 100%;
       padding-left: 0;
    }
`


const OurTeamLeft = styled(motion.div)`
    width: 50%;
    padding-right: 2rem;

    @media screen and (max-width: 1130px){
       width: 100%;
       padding-left: 0;
    }

`

const TeamItem = styled(motion.div)`
    display: flex;
    flex-direction: column;
    width: 100%;
    background: rgba(34,183,143,.1);
    border: 2px solid ${({theme}) => theme.colors.darkGreen};
    justify-content: center;
    align-items: center;
    cursor: pointer;
    transition: .4s;

    ${props => props.isActive && css`

        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    
    `}

    &:hover{
        border: 2px solid ${({theme}) => theme.colors.green};
        -webkit-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        -moz-box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
        box-shadow: 0px 0px 24px 0px ${({theme}) => theme.colors.green};
    }
`

const TeamImg = styled(motion.img)`
    width: 100%;
    height: 100%;
    user-select: none;
`

const TeamTextContent = styled(motion.div)`
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start;
    width: 100%;
    padding: 1rem;
    user-select: none;
`

const TeamName = styled(motion.h2)`
    display: block;
    font-family: ${({theme}) => theme.font.primaryFont};
    color: ${({theme}) => theme.colors.white};
    font-weight: 300;

`

const TeamInfo = styled(motion.p)`
    display: block;
    font-family: ${({theme}) => theme.font.secondFont};
    color: ${({theme}) => theme.colors.textColor};
    font-weight: 300;
    font-size: 14px;
    margin-bottom: 1rem;
    letter-spacing: 1px;

`

const TeamSocials = styled(motion.div)`
    width: 100%;
    display: flex;
`

const TeamSocial = styled(motion.div)`
    display: flex;
    justify-content: center;
    align-items: center;
    border-radius: 5px;
    color: ${({theme}) => theme.colors.white};
    margin-right: 1rem;
    background: ${({theme}) => theme.colors.green};
    font-size: 1.2rem;
    padding: 0.3rem;
    opacity: .7;
    transition: .4s;


    &:hover{
        opacity: 1;
    }
`

export { 
    OurTeamElement, 
    OurTeamCarousel, 
    OurTeamLeft, 
    OurTeamElementContent,
    TeamItem,
    TeamImg,
    TeamTextContent, 
    TeamInfo,
    TeamName,
    TeamSocials,
    TeamSocial
    

}