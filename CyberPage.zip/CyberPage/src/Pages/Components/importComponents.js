import AboutComponent from "./AboutComponent/AboutComponent"
import ImageAnimate from './ImageAnimate/ImageAnimate'
import Roadmap from "./Roadmap/Roadmap"
import HowWeWork from "./HowWeWork/HowWeWork"
import OurTeam from "./OurTeam/OurTeam"
import LastBlog from "./LastBlog/LastBlog"
import Partners from "./Partners/Partners"
import FAQS from "./FAQS/FAQS"
import Header from "./Header/Header"
import ContactComponent from "./ContactComponent/ContactComponent"
export{ 
    AboutComponent, 
    ImageAnimate, 
    Roadmap, 
    HowWeWork, 
    OurTeam, 
    LastBlog, 
    Partners, 
    FAQS, 
    Header, 
    ContactComponent 
}