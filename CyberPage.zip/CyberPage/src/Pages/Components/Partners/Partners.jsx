import React from 'react'
import { HeadingSectionCenter } from '../../../Elements/importElements'
import { PartnersElement, PartnersCarousel, PartnersContent } from './StyledPartners'
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import { Partner1, Partner2, Partner3 } from '../../../importImages';

const partnersList = [
    {
        id: 1,
        img: `${Partner1}`
    },
    {
        id: 2,
        img: `${Partner2}`
    },
    {
        id: 3,
        img: `${Partner3}`
    },
    {
        id: 4,
        img: `${Partner2}`
    },
    {
        id: 5,
        img: `${Partner3}`
    },
    {
        id: 6,
        img: `${Partner1}`
    },
    {
        id: 7,
        img: `${Partner3}`
    },
    {
        id: 8,
        img: `${Partner2}`
    },

]

function slides() {
 let width = window.innerWidth;

 if(width > 900){
    return 6;
 }if(width < 900 && width > 501){
    return 3;
 }if(width <= 500){
    return 2;
 }
} 

slides();

const Partners = () => {
  return (
    <PartnersElement
    initial={{opacity: 0}}
    whileInView={{opacity: 1}}
    transition={{duration: 1}}
    viewport={{once: true}}
>
        <PartnersContent>
            <HeadingSectionCenter 
            sectionName='Partners'
            title='SpaceIT Investors'
            />
            <PartnersCarousel>
                <Swiper

                    slidesPerView={slides()}
                    spaceBetween={30}
                    className="mySwiper"
                >
                    {partnersList.map((props) => (
                        <SwiperSlide><img src={props.img} alt= ''/></SwiperSlide>
                    ))}
                </Swiper>
            </PartnersCarousel>
      </PartnersContent>
    </PartnersElement>
  )
}

export default Partners