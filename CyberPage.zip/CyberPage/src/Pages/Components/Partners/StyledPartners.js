import styled from "styled-components";
import { motion } from "framer-motion";

const PartnersElement = styled(motion.div)`
    width: 100%;
    background-color: ${({theme}) => theme.colors.lightBackground};
    padding: 4rem 0;
    overflow: hidden;
`
const PartnersCarousel = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;

    ${({theme}) => theme.media.desktop}{
        padding: 4rem;
    }

    ${({theme}) => theme.media.mobile}{
        padding: 4rem 1rem;
    }
`
const PartnersContent = styled(motion.div)``


export {
    PartnersElement,
    PartnersCarousel,
    PartnersContent
}