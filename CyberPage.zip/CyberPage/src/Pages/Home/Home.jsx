import React from 'react'
import { Slider } from '../../Elements/importElements'
import { AboutComponent, ImageAnimate, Roadmap, HowWeWork, OurTeam, LastBlog, Partners, FAQS } from '../Components/importComponents'

const Home = () => {
  return (
    <>
    <Slider />
    <AboutComponent />
    <ImageAnimate />
    <Roadmap />
    <HowWeWork />
    <OurTeam />
    <LastBlog />
    <Partners />
    <FAQS />
    </>
  )
}

export default Home