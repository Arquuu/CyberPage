import styled from "styled-components";
import { motion } from "framer-motion";

export const ContactContainer = styled(motion.div)`
    max-width: 1440px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;

`
export const ContactLeft = styled(motion.div)``
export const ContactRight = styled(motion.div)``