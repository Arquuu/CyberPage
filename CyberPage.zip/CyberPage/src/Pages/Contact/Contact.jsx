import React from 'react'
import { ContactComponent, Header } from '../Components/importComponents'
const Contact = () => {
  return (
    <>
      <Header
      title='Contact' 
      />
      <ContactComponent />
    </>
  )
}

export default Contact