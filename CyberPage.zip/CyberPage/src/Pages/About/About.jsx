import React from 'react'
import { AboutComponent, HowWeWork, OurTeam, Header, FAQS } from '../Components/importComponents'
const About = () => {
  return (
    <div>
      <Header 
      title='About'
      />
      <AboutComponent />
      <OurTeam />
      <HowWeWork />
      <FAQS />
    </div>
  )
}

export default About