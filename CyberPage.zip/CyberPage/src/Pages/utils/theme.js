export const theme = {
    colors: {
        white: '#fff',
        green: '#14c2a3',
        darkGreen: '#105252',
        darkBackground: '#0c1226',
        lightBackground: '#141a31',
        textColor: '#b9b9bf',
    },

    font: {
        primaryFont: 'Chakra Petch',
        secondFont: 'IBM Plex Mono'
    },

    media: { 
        mobile: '@media (max-width: 500px)',
        tablet: '@media (max-width: 900px)',
        desktop: '@media (max-width: 1440px)'
    }

}