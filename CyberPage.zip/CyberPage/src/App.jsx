import React, {useState } from 'react'
import { BrowserRouter as Router, Routes, Route} from 'react-router-dom'
import { Home, About, Blog, Contact } from './Pages/importPages'
import { Logo, MenuList, MobileFix, MenuIcon, Links, NavbarContent, NavBar, aHref, ButtonTop, GlobalStyle, Footer, FooterImg1, FooterImg3, FooterSocial, FooterTextContainer, FooterTitle, FooterDescription, FooterInputs, FooterInput, FooterLinks, FooterIcon  } from './StyledApp'
import { FooterImg, FooterImg2, LogoSpace } from './importImages'
import { ThemeProvider} from 'styled-components'
import { theme } from './Pages/utils/theme'
import { Button, ButtonSecond } from './Elements/importElements'
import { AiOutlineUser, AiOutlineHome } from 'react-icons/ai'
import { BsFillJournalBookmarkFill, BsPencilSquare, BsArrowUp } from 'react-icons/bs'
import PropTypes from 'prop-types';
import { ScrollNavbar } from './ScrollNabar/ScrollNavbar'
import { BsTwitter, BsFacebook, BsYoutube} from 'react-icons/bs'
import { FaDiscord } from 'react-icons/fa'
const App = () => {
    const [activeMenu, setActiveMenu] = useState(3);
    const scrollPosition = ScrollNavbar();

    const buttonScrollUp = () => {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        })
    }
    const LinkScrollUp = () => {
        window.scrollTo({
            top: 0,
        })
    }


    const ActiveOne = () => {
        setActiveMenu(1)
        LinkScrollUp()
    }
    const ActiveTwo = () => {
        setActiveMenu(2)
        LinkScrollUp()
    }
    const ActiveThree = () => {
        setActiveMenu(3)
        LinkScrollUp()
    }
    const ActiveFour = () => {
        setActiveMenu(4)
        LinkScrollUp()
    }


  return (
    <ThemeProvider theme={theme} >
    <GlobalStyle />
    <Router>
        <NavBar
        isActiveNav={scrollPosition > 300 ? 'Active' : ''}>
            <NavbarContent
            initial={{opacity: 0, y: -200}}
            animate={{opacity: 1, y: 0}}
            isActiveNav={scrollPosition > 300 ? 'Active' : ''}>
                <Links to='/'>
                <Links menuDesktop='menuDesktop' to='/'><aHref onClick={LinkScrollUp}><h1>SPACEIT</h1></aHref></Links>  {/* <------- Alpha Version */}
                </Links>
                <MenuList >
                    <Links menuDesktop='menuDesktop' to='/about' ><aHref onClick={LinkScrollUp}>About</aHref></Links>
                    <Links menuDesktop='menuDesktop' to='/blog'><aHref onClick={LinkScrollUp}>Blog</aHref></Links>
                    <Links menuDesktop='menuDesktop' to='/contact'><aHref onClick={LinkScrollUp}>Contact</aHref></Links>
                    <Button
                    link='contact'
                    text='Join discord' 
                    />
                </MenuList>
            </NavbarContent>
        </NavBar>
        <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/about' element={<About />} />
            <Route path='/blog' element={<Blog />} />
            <Route path='/contact' element={<Contact />} />
        </Routes>

        <MobileFix isActive={scrollPosition > 300 ? 'Active' : ''}>
            <MenuIcon onClick={ActiveOne} isActive={activeMenu === 1 ? 'Active' : ''}><Links to='/about'><AiOutlineUser /></Links></MenuIcon>
            <MenuIcon onClick={ActiveTwo} isActive={activeMenu === 2 ? 'Active' : ''}><Links to='/blog'><BsFillJournalBookmarkFill /></Links></MenuIcon>
            <MenuIcon onClick={ActiveThree} isActive={activeMenu === 3 ? 'Active' : ''}><Links to='/'><AiOutlineHome /></Links></MenuIcon>
            <MenuIcon onClick={ActiveFour} isActive={activeMenu === 4 ? 'Active' : ''}><Links to='/contact'><BsPencilSquare /></Links></MenuIcon>
            <MenuIcon onClick={buttonScrollUp}><BsArrowUp /></MenuIcon>
        </MobileFix>

        <ButtonTop 
        whileTap={{scale:.9}} 
        onClick={buttonScrollUp} isActive={scrollPosition > 500 ? 'Active' : ''}
        >
            <BsArrowUp />
        </ButtonTop>

        <Footer>
            <FooterImg1 src={FooterImg} alt='' />
            <FooterImg3 src={FooterImg2} alt='' />
            <FooterSocial>
            <FooterIcon><BsTwitter /></FooterIcon>
            <FooterIcon><BsFacebook /></FooterIcon>
            <FooterIcon><BsYoutube /></FooterIcon>
            <FooterIcon><FaDiscord /></FooterIcon>
            </FooterSocial>

            <FooterTextContainer>
                <FooterTitle>Don't Miss Out, Join Now For Early Access</FooterTitle>
                <FooterDescription>Maecenas Sit Pretium, Cras In. In Quisque Sem Id Eget. In Vel Gravida Ut</FooterDescription>
            </FooterTextContainer>
            <FooterInputs>
                <FooterInput type='text' placeholder='Enter Your Email Address'/><ButtonSecond link='#' text='Send'/>
            </FooterInputs>

            <FooterLinks>
                <FooterDescription>
                SpaceIT 2022 ALL Rights Reserved
                </FooterDescription>
            </FooterLinks>


        </Footer>
    </Router>
    </ThemeProvider>

  )
}

export default App