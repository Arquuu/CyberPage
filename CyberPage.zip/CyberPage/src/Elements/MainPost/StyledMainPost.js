import styled from "styled-components";
import { motion } from "framer-motion";

export const MainPostElement = styled(motion.div)`
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    border-bottom: 1px solid ${({theme}) => theme.colors.green};;
`

export const PostCategory = styled(motion.div)`
    position: absolute;
    top: 50px;
    left: 50px;
    background-color: ${({theme}) => theme.colors.green};
    font-family: ${({theme}) => theme.font.secondFont};
    padding: 0.5rem 1rem;
    color: ${({theme}) => theme.colors.white};
    letter-spacing: 1px;

    ${({theme}) => theme.media.mobile}{
        top: 20px;
        left: 20px;
    }

`
export const PostImg = styled(motion.img)`
    width: 100%;
    height: 100%;
`
export const PostTop = styled(motion.div)`
    width: 100%;
    position: relative;
`
export const PostBottom = styled(motion.div)`
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
`
export const PostInfo = styled(motion.p)`
    color: ${({theme}) => theme.colors.white};
    font-family: ${({theme}) => theme.font.secondFont};
    display: block;
    padding-top: 1rem;
    font-size: 1.1rem;

`
export const PostTitle = styled(motion.h1)`
    color: ${({theme}) => theme.colors.white};
    display: block;
    width: 100%;
    padding: 1rem 0;
    font-size: 2rem;
    cursor: pointer;
    transition: .4s;
    &:hover{
        color: ${({theme}) => theme.colors.green};
    }
`
export const PostDescription = styled(motion.p)`
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    display: block;
    font-size: 1.1rem;
    line-height: 1.5;

`
export const ReadMore = styled(motion.p)`
    font-size: 1.2rem;
    color: ${({theme}) => theme.colors.white};
    margin: 2rem 0;
    cursor: pointer;
    transition: .4s;
    width: max-content;
    text-transform: uppercase;
    &:hover{
        color: ${({theme}) => theme.colors.green};
    }
`
