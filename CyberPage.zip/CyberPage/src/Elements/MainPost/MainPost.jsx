import React from 'react'
import { PostImg1 } from '../../importImages';
import { MainPostElement, PostCategory, PostImg, PostTop, PostBottom, PostInfo, PostTitle, PostDescription, ReadMore } from './StyledMainPost';
const PostContent = [
  {
    id: 1,
    img: `${PostImg1}`,
    category: 'Nftartwork',
    author: 'Arquuu',
    data: '20 jun 2022',
    title: 'Convert More Leads With These Three New Follow-Up Ideas',
    description: `  We make daily use products more affordable and accessible for a 
                    billion Indians by using our in-house technology to power one of the world's most efficient grocery supply chains. 
                    We make daily use products more affordable and accessible for a...`
  }
]




const MainPost = () => {
  return (
    <>
      {PostContent.map((props) => (
      <MainPostElement>
      <PostTop>
      <PostCategory>{props.category}</PostCategory>
      <PostImg src={props.img} alt='' />
    </PostTop>
    <PostBottom>
      <PostInfo>by {props.author} | {props.data}</PostInfo>
      <PostTitle>{props.title}</PostTitle>
      <PostDescription>{props.description}
      </PostDescription>
      <ReadMore>Read more</ReadMore>
    </PostBottom>
    </MainPostElement>
      ))}
    </>
  )
}

export default MainPost