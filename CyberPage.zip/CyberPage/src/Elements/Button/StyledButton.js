import styled, { css } from "styled-components";
import { Link } from 'react-router-dom';
import { motion } from "framer-motion";

export const ButtonPrimary = styled(motion.a)`
    position: relative;
    font-size: 1rem;
    text-transform: uppercase;
    font-weight: 700;
    border: 2px solid var(--green-main);
    cursor: pointer;
    color: ${({theme}) => theme.colors.white};
    border: 2px solid ${({theme}) => theme.colors.green};
    transition: .4s;
    max-width: max-content;
    ${props => props.bg && css`
        background-color: ${({theme}) => theme.colors.green};
    `}

    &::before{
        position: absolute;
        content: '';
        left: -2px;
        top: 50%;
        width: 2px;
        height: 0%;
        background-color: ${({theme}) => theme.colors.white};
        transition: .4s;
    }

    &:hover{
        background-color: transparent;
    }

    &:hover::before{
        height: 100%;
        top: 0;
    }

    &::after{
        position: absolute;
        content: '';
        right: -2px;
        top: 50%;
        width: 2px;
        height: 0%;
        background-color: ${({theme}) => theme.colors.white};
        transition: .4s;
    }

    &:hover::after{
        height: 100%;
        top: 0;
    }
`

export const EffectButton = styled(motion.div)`
    width: 100%;
    height: 100%;
    display: block;
    padding: 0.8rem 1.6rem;
    max-width: max-content;

    &::before{
        position: absolute;
        content: '';
        left: 50%;
        top: -2px;
        width: 0;
        height: 2px;
        background-color: ${({theme}) => theme.colors.white};
        transition: .4s;
    }

    &:hover::before{
        width: calc(100% + 4px);
        left: -2px;
    }

    &::after{
        position: absolute;
        content: '';
        left: 50%;
        bottom: -2px;
        width: 0;
        height: 2px;
        background-color: ${({theme}) => theme.colors.white};
        transition: .4s;
    }

    &:hover::after{
        width: calc(100% + 4px);
        left: -2px;
    }

`
export const Links = styled(Link)`
    display: block;
    margin-right: 0;
    color: ${({theme}) => theme.colors.white};
    transition: .4s;
`