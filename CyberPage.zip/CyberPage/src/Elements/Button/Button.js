import React from 'react'
import { ButtonPrimary, EffectButton, Links } from './StyledButton';
const Button = (props) => {
  return (
    <>
    <ButtonPrimary>
    <EffectButton>
        <Links to={`/${props.link}`}>
            {props.text}
        </Links>
    </EffectButton>
    </ButtonPrimary>
    </>
  )
}

export default Button