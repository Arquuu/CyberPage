import React from 'react'
import { ButtonPrimary, EffectButton, Links } from './StyledButton';
const ButtonSecond = (props) => {
  return (
    <>
    <ButtonPrimary bg='bg'>
    <EffectButton>
        <Links to={`/${props.link}`}>
            {props.text}
        </Links>
    </EffectButton>
    </ButtonPrimary>
    </>
  )
}

export default ButtonSecond