import React, { useState } from 'react'
import { AiOutlinePlus, AiOutlineMinus } from 'react-icons/ai'
import {TopContainer, Title, Icon, PopularTagsContainer, TagsTitle, TagsContent} from './StyledPopularTags'

const Tags = [
  {
    id: 1,
    title: 'nftartwork',
  },
  {
    id: 2,
    title: 'rarible',
  },
  {
    id: 3,
    title: 'btc',
  },
  {
    id: 4,
    title: 'animation',
  },
  {
    id: 5,
    title: 'cryptocurrencies',
  }
]


const PopularTags = () => {

  const [active, setActive] = useState(true);
  return (
    <PopularTagsContainer>
      <TopContainer
      onClick={() => setActive(prevState => (!prevState))}>
        <Title>Popular Tags</Title>
        { active === true
         ? <Icon><AiOutlineMinus /></Icon>
         : <Icon><AiOutlinePlus /></Icon> 
        }
      </TopContainer>
      {active && (
      <TagsContent>
      {Tags.map((props) =>(
          <TagsTitle>
            {props.title}
          </TagsTitle>
      ))}
    </TagsContent>

      )}
    </PopularTagsContainer>
  )
}

export default PopularTags