import styled from "styled-components";
import { motion } from "framer-motion";

export const TopContainer = styled(motion.div)`
    width: 100%;
    border-bottom: 1px solid ${({theme}) => theme.colors.darkGreen};
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    margin-bottom: 2rem;
`
export const Title = styled(motion.h1)`
    color: ${({theme}) => theme.colors.white};
    display: flex;
    position: relative;
    padding-bottom: 1rem;

    &::before{
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 80px;
        height: 2px;
        background-color: ${({theme}) => theme.colors.green};
    }
`
export const Icon = styled(motion.div)`
    display: flex;
    align-items: center;
    justify-content: center;
    color: ${({theme}) => theme.colors.white};
    font-size: 1.5rem;
    padding-bottom: 1rem;
`
export const PopularTagsContainer = styled(motion.div)`
    width: 100%;
    display: flex;
    flex-direction: column;
    user-select: none;
`
export const TagsTitle = styled(motion.p)`
    background-color: ${({theme}) => theme.colors.darkGreen};
    padding: .5rem 1rem;
    color: ${({theme}) => theme.colors.white};
    font-family: ${({theme}) => theme.font.secondFont};
    display: flex;
    justify-content: center;
    width: max-content;
    margin-bottom: 10px;
    margin-right: 8px;
    transition: all .3s ease;
    cursor: pointer;

    &:hover{
        background-color: ${({theme}) => theme.colors.green};
    }
`
export const TagsContent = styled(motion.div)`
    width: 100%;
    display: flex;
    flex-wrap: wrap;
`