import styled from "styled-components";
import { motion } from "framer-motion";
const IndicatorWrapper = styled.div`
    display: flex;
    flex-wrap: nowrap;
    position: absolute;
    bottom: 50px;
    right: 50px;

    ${({theme}) => theme.media.mobile}{
        display: none;
    }
`

const Dot = styled.div`
    width: ${props => props.isActive ? '15px' : '5px'};
    height: 5px;
    border-radius: 10px;
    background-color: ${({theme}) => theme.colors.green};
    opacity: ${props => props.isActive ? .5 : .3};
    margin-left: 10px;
    cursor: pointer;
    transition: .7s;
    box-shadow: 1px 1px 24px -9px rgba(0, 0, 0, 1);
    z-index: 5;
`

const Wrapper = styled(motion.div)`
    height: 100vh;
    display: flex;
    flex-wrap: nowrap;
    overflow: hidden;
`

const Slide = styled(motion.div)`
    height: 100%;
    width: 100%;
    flex-shrink: 0;
    background-position: center;
    background-size: cover;
    transition: .7s;
    display: flex;
    justify-content: center;
    align-items: center;

    ${({theme}) => theme.media.desktop} {
        padding:  0 4rem;
    }

    ${({theme}) => theme.media.mobile} {
        padding: 0 1rem;
    }
`

const SlideContent = styled(motion.div)`
    position: relative;
    max-width: 1440px;
    height: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;

    ${({theme}) => theme.media.mobile} {
        max-width: 100%;
    }
`

const ColLeft = styled(motion.div)`
    width: ${({theme}) => theme.media.tablet ? '100%' : '50%'};
    display: flex;
    position: relative;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start;
    user-select: none;
`

const SlideText = styled(motion.div)`
    display: flex;
    flex-direction: column;
    width: 100%;
    height: 100%;
    align-items: flex-start;
    justify-content: space-between;
`

const SlideTitle = styled(motion.h1)`
    font-size: 80px;
    text-transform: uppercase;
    color: ${({theme}) => theme.colors.white};

    ${({theme}) => theme.media.desktop} {
        font-size: 60px;
    }

    ${({theme}) => theme.media.mobile} {
        font-size: 40px;
    }
`

const SlideDescription = styled(motion.p)`
    font-size: 1rem;
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    letter-spacing: 2px;
    margin-top: 1rem;

    ${({theme}) => theme.media.mobile} {
        font-size: 14px;
    }

`

const ColRight = styled(motion.div)`
    position: relative;
    height: 100%;
    width: 50%;
    right: 0;
    z-index: 2;
    bottom: 0;
    user-select: none;

    ${({theme}) => theme.media.tablet} {
        display:  none;
    }
`

const ImgItem = styled(motion.img)`
    position: absolute;
    right: 0;
    bottom: 0;
    animation: anime 5s linear infinite;
    user-select: none;
    @media screen and (min-width: 1921px){
        bottom: 20%;
    }

    @keyframes anime {
        0%{
            transform: translateX(0);
        }

        50%{
            transform: translateX(-2%);
        }

        75%{

            transform: translateX(2%);
        }

        100%{
            transform: translateX(0);
        }
    }
`

const ArrowContainer = styled.div`
    position: absolute;
    height: max-content;
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    bottom: 50%;

    ${({theme}) => theme.media.tablet} {
        bottom: 20px;
    }
`

const ArrowContent = styled(motion.div)`
    border: 2px solid ${({theme}) => theme.colors.green};
    font-size: 2rem;
    color: ${({theme}) => theme.colors.white};
    border-radius: 50%;
    padding: 1rem;
    cursor: pointer;
    display: flex;
    justify-content: center;
    align-items: center;
    margin: 0 2rem;
    z-index: 99;
    opacity: ${props => props.option === 'Yes' ? 0.5 : 1} !important;
    &:hover{
        background-color: ${({theme}) => theme.colors.green};
    }
    ${({theme}) => theme.media.mobile} {
        padding: 0.5rem;
        font-size: 1rem;
    }
`

const Overlay = styled.div`
    width: 100%;
    height: 100%;
    position: absolute;
    top: 0;
    left: 0;
    background-color: rgba(0, 0, 0, 0.4);
`

const ButtonContainer = styled(motion.div)`
    width: 370px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-top: 3rem;

    ${({theme}) => theme.media.mobile} {
        flex-direction: column;
        align-items: flex-start;
        width: 100%;
        margin-top: 2rem;
        gap: 1rem;
    }
`

export { 
    IndicatorWrapper,
    Dot,
    Wrapper,
    Slide,
    SlideContent,
    ColLeft,
    SlideText,
    SlideTitle,
    SlideDescription,
    ColRight,
    ImgItem,
    ArrowContainer,
    ArrowContent,
    Overlay,
    ButtonContainer
}