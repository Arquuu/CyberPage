import React, {useEffect, useState} from 'react';
import { MdKeyboardArrowLeft, MdKeyboardArrowRight } from 'react-icons/md';
import { ImgBg1, ImgBg2, ImgBg3, ImgItemS } from '../../importImages';
import { Button, ButtonSecond } from '../../Elements/importElements';
import { IndicatorWrapper, Dot, Wrapper, Slide, SlideContent, ColLeft, SlideText, SlideTitle, SlideDescription, ColRight, ImgItem, ArrowContainer, ArrowContent, Overlay, ButtonContainer } from './StyledSlider';
const slideContent = [
    {
        image: `${ImgBg1}`,
        title: 'Cybox nft collections for everyone',
        text: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolore at porro quod similique! Doloribus asperiores tempora maiores. Neque, non sit.',
        buttonText1: 'Connect wallet',
        buttonText2: 'Watch video',
        photoItem: `${ImgItemS}`
    },
    {
        image: `${ImgBg2}`,
        title: 'Cybox nft collections for everyone',
        text: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolore at porro quod similique! Doloribus asperiores tempora maiores. Neque, non sit.',
        buttonText1: 'Watch video',
        buttonText2: 'Connect wallet',
    },
    {
        image: `${ImgBg3}`,
        title: 'Cybox nft collections for everyone',
        text: 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolore at porro quod similique! Doloribus asperiores tempora maiores. Neque, non sit.',
        buttonText1: 'Connect wallet',
        buttonText2: 'Read More',
    }
]



const Slider = ({ 
    images = [], 
    autoPlay = true, 
    autoPlayTime = 300000,
    ...props 
}) => {
    const [currentSlide, setCurrentSlide] = useState(0);

    function nextSlide(slideIndex = currentSlide + 1){

        const newSlideIndex = slideIndex >= slideContent.length ? 0 : slideIndex;
        setCurrentSlide(newSlideIndex);

    }

    useEffect(() => {
        const timer = setTimeout(() => {
            nextSlide()
        }, autoPlayTime)

        return () => clearTimeout(timer);
    }, [currentSlide]);

    const Indicator = ({currentSlide, amountSlides, nextSlide}) => {
        return (
            <IndicatorWrapper>
                {Array(amountSlides)
                .fill(1)
                .map((_, i) => (
                    <Dot key={i} 
                    isActive={currentSlide === i} 
                    onClick={() => nextSlide(i)}
                    />
                ))}
    
            </IndicatorWrapper>
        )
    }

    return (
        <Wrapper >
            <Overlay />
            {slideContent.map((slide, index) => (
                <Slide
                key = {index}
                style = {{backgroundImage: `url(${slide.image})`, marginLeft: index === 0 ? `-${currentSlide * 100}%` : undefined}}
                >
                    <SlideContent>
                        <ColLeft>
                        <SlideText>
                            <SlideTitle
                            initial={{opacity: 0, y: -100}}
                            whileInView={{opacity: 1, y: 0}}
                            transition={{delay: .3}}>
                                {slide.title}
                            </SlideTitle>
                            <SlideDescription
                            initial={{opacity: 0, y: 100}}
                            whileInView={{opacity: 1, y: 0}}
                            transition={{delay: .3}}>
                                {slide.text}
                            </SlideDescription>
                        </SlideText>
                        <ButtonContainer
                            initial={{opacity: 0, x: 100}}
                            whileInView={{opacity: 1, x: 0}}
                            transition={{delay: .3}}
                        >
                        <ButtonSecond
                        link = '#'
                        text = {slide.buttonText1} 
                        />
                        <Button 
                        link = '#'
                        text = {slide.buttonText2} 
                        />
                        </ ButtonContainer>
                        </ColLeft>

                        <ColRight
                            initial={{opacity: 0, y: 100}}
                            whileInView={{opacity: 1, y: 0}}
                            transition={{ delay: .3 }}
                            
                        >
                        <ImgItem
                        src = {slide.photoItem} 
                        alt = '' />
                        </ColRight>
                    </SlideContent>
                </Slide>
            ))}
            <Indicator 
            currentSlide = {currentSlide}
            amountSlides = {slideContent.length}
            nextSlide = {nextSlide}
             />
             <ArrowContainer>
                <ArrowContent
                whileTap={{scale: 0.9}}
                initial={{opacity: 0, y: -100}}
                whileInView={{opacity: 1, y: 0}}             
                onClick={() => setCurrentSlide(currentSlide - 1 < 0 ? 0 : currentSlide - 1 )}
                option={currentSlide === 0 ? 'Yes': ''}
                viewport={{once: true}}>
                    <MdKeyboardArrowLeft />
                </ArrowContent>
                <ArrowContent
                whileTap={{scale: 0.9}}
                initial={{opacity: 0, y: -100}}
                whileInView={{opacity: 1, y: 0}} 
                onClick={() => setCurrentSlide(currentSlide + 1 >= slideContent.length ? 2 : currentSlide + 1 )}
                option={ currentSlide + 1 === slideContent.length ? 'Yes' : ''}
                viewport={{once: true}}>
                    <MdKeyboardArrowRight />
                </ArrowContent>
             </ArrowContainer>
        </Wrapper>
    )
}

export default Slider;