import React, { useState } from 'react'
import { ButtonPag, ButtonContainer } from './StyledPaginationButton'
const CountButton = [
  {
  id: 1,
  },
  {
  id: 2,
  },
  {
  id: 3,
  },
  {
  id: 4,
  },
  {
  id: 5,
  },
]

const PaginationButton = () => {
  const [active, setActive] = useState(1)

  return (
    <ButtonContainer>
          {CountButton.map((props) =>(
    <ButtonPag
    onClick={() => setActive(props.id)}
    isActive={`${active === props.id ? 'Active' : ''}`}>
      {props.id}
    </ButtonPag>
        ))}
    </ButtonContainer>
  )
}

export default PaginationButton