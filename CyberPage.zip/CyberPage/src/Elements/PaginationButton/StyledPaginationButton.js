import styled, {css} from "styled-components";
import { motion } from "framer-motion";

export const ButtonContainer = styled(motion.div)`
    margin: 2rem 0;
    width: 100%;
    display: flex;
    align-items: flex-start;
`
export const ButtonPag = styled(motion.div)`
    display: flex;
    justify-content: center;
    align-items: center;
    width: 50px;
    height: 50px;
    font-size: 1.5rem;
    color: ${({theme}) => theme.colors.white};
    margin-right: 1rem;
    border: 1px solid ${({theme}) => theme.colors.darkGreen};
    cursor: pointer;
    transition: .4s;

    ${props => props.isActive && css`
    background-color: ${({theme}) => theme.colors.green};
    `}

    &:hover{
        background-color: ${({theme}) => theme.colors.green};
    }

`