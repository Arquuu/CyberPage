import styled from "styled-components";
import { motion } from "framer-motion";

export const PostItemElement = styled(motion.div)`
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid ${({theme}) => theme.colors.darkGreen};
    padding: 2rem 0;
    
    @media screen and (max-width: 1230px){
        flex-direction: column;
        align-items: flex-start;
    }
`
export const ItemsLeft = styled(motion.div)`
    height: 100%;
    position: relative;
    flex-basis: 50%;
`
export const PostCategory = styled(motion.div)`
    position: absolute;
    top: 20px;
    right: 20px;
    background-color: ${({theme}) => theme.colors.green};
    font-family: ${({theme}) => theme.font.secondFont};
    padding: 0.5rem 1rem;
    color: ${({theme}) => theme.colors.white};
    letter-spacing: 1px;

`
export const ItemImg = styled(motion.img)`
    width: 100%;
    height: 100%;
`
export const ItemsRight = styled(motion.div)`
    flex-basis: 50%;
    display: flex;
    flex-direction: column;
    margin-left: 2rem;

    @media screen and (max-width: 1230px){
        margin: 2rem 0 0 0;
    }
`
export const PostInfo = styled(motion.p)`
    color: ${({theme}) => theme.colors.white};
    display: block;
    font-family: ${({theme}) => theme.font.secondFont};
    padding-bottom: 1rem;

`
export const PostTitle = styled(motion.h1)`
    color: ${({theme}) => theme.colors.white};
    display: block;
    padding-bottom: 1rem;
    font-size: 1.5rem;

    cursor: pointer;
    transition: .4s;
    &:hover{
        color: ${({theme}) => theme.colors.green};
    }

`
export const PostDescription = styled(motion.p)`
    color: ${({theme}) => theme.colors.textColor};
    display: block;
    font-family: ${({theme}) => theme.font.secondFont};
    padding-bottom: 2rem;
`
export const ReadMore = styled(motion.p)`
    font-size: 1.2rem;
    color: ${({theme}) => theme.colors.white};
    cursor: pointer;
    transition: .4s;
    width: max-content;
    text-transform: uppercase;
    &:hover{
        color: ${({theme}) => theme.colors.green};
    }


`
