import React from 'react'
import { PostImg4, PostImg2, PostImg3 } from '../../importImages'
import { PostItemElement, ItemsLeft, ItemImg, ItemsRight, PostInfo, PostCategory, PostTitle, PostDescription, ReadMore } from './StyledPostItem'
const PostsContent = [
  {
    id: 1,
    img: `${PostImg2}`,
    category: 'Nftartwork',
    author: 'Arquuu',
    data: '20 Jun 2022',
    title: 'Why Choose A Theme That Looks Good With WooCommerce',
    description: 'We make daily use products more affordable & accessible for a billion Indians by using our...'
  },
  {
    id: 2,
    img: `${PostImg3}`,
    category: 'Digitalart',
    author: 'Arquuu',
    data: '20 Jun 2022',
    title: 'Why Choose A Theme That Looks Good With WooCommerce',
    description: 'We make daily use products more affordable & accessible for a billion Indians by using our...'
  },
  {
    id: 3,
    img: `${PostImg4}`,
    category: 'Nftartwork',
    author: 'Arquuu',
    data: '20 Jun 2022',
    title: 'Why Choose A Theme That Looks Good With WooCommerce',
    description: 'We make daily use products more affordable & accessible for a billion Indians by using our...'
  },

]




const PostItem = () => {
  return (
    <>
    {PostsContent.map((props) => (
    <PostItemElement>
    <ItemsLeft>
    <PostCategory>{props.category}</PostCategory>
    <ItemImg src={props.img} alt ='' />
    </ItemsLeft>
    <ItemsRight>
    <PostInfo>by {props.author} | {props.data}</PostInfo>
    <PostTitle>{props.title}</PostTitle>
    <PostDescription>{props.description}</PostDescription>
    <ReadMore>Read More</ReadMore>
    </ItemsRight>
  </PostItemElement>

    ))}

    </>
  )
}

export default PostItem