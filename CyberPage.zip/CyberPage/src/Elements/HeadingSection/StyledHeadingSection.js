import styled, {css} from "styled-components";
import { motion } from "framer-motion";

export const HeadingSectionContent = styled(motion.div)`
    width: 100%;
    height: max-content;
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    justify-content: space-between;

    ${props => props.isCenter && css`
    align-items: center;
    text-align: center;
    `}
`
export const SectionName = styled(motion.h4)`
    display: block;
    font-size: 1.5rem;
    line-height: 1.6;
    letter-spacing: 1px;
    color: ${({theme}) => theme.colors.green};
    font-family: ${({theme}) => theme.font.secondFont};
    font-weight: 700;
    text-transform: uppercase;
    margin-bottom: 10px;

    ${({theme}) => theme.media.tablet} {
        font-size: 1.2rem;
    }
`
export const SectionTitle = styled(motion.h1)`
    display: block;
    font-size: 3rem;
    line-height: 1.25;
    text-transform: uppercase;
    font-family: ${({theme}) => theme.font.primaryFont};
    color: ${({theme}) => theme.colors.white};
    margin-bottom: 1rem;

    ${({theme}) => theme.media.tablet} {
        font-size: 2rem;
    }
`
export const SectionDescription = styled(motion.p)`
    display: block;
    font-size: 1.1rem;
    line-height: 1.8;
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    margin-bottom: 3rem;

    ${({theme}) => theme.media.tablet} {
        font-size: 1rem;
    }
`