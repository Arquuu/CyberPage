import React from 'react'
import { HeadingSectionContent, SectionName, SectionTitle, SectionDescription } from './StyledHeadingSection'
const HeadingSection = (props) => {
  return (
    <>
        <HeadingSectionContent isCenter>
            <SectionName>{props.sectionName}</SectionName>
            <SectionTitle>{props.title}</SectionTitle>
            <SectionDescription>{props.description}</SectionDescription>
        </HeadingSectionContent>
    </>
  )
}

export default HeadingSection