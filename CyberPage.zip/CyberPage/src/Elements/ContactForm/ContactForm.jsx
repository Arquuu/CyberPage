import React from 'react'
import { Button } from '../importElements'
import { ContactFormElement, TitleForm, DescriptionForm, Form, InputFrom, InputMessage } from './StyledContactForm'
const ContactForm = () => {
  return (
    <ContactFormElement>
        <TitleForm> Have a question</TitleForm>
        <DescriptionForm>Fill up the Form and ou team will get back to within 24 hrs</DescriptionForm>
        <Form>
            <InputFrom type='text' placeholder='Name'/>
            <InputFrom type='email' placeholder='Email Address'/>
            <InputFrom type='tel' placeholder='Phone Number'/>
            <InputMessage rows={4} placeholder='Your Message'/>
            <Button
            text="Send message" />
        </Form>

    </ContactFormElement>
  )
}

export default ContactForm