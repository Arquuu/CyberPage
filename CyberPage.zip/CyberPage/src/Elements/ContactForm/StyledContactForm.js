import styled from "styled-components";
import { motion } from "framer-motion";

export const ContactFormElement = styled(motion.div)`
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
`

export const TitleForm = styled(motion.h1)`
    color: ${({theme}) => theme.colors.white};
    text-transform: uppercase;
    font-size: 2.5rem;
    margin-bottom: 1rem;
`

export const DescriptionForm = styled(motion.p)`
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    margin-bottom: 2rem;
`

export const Form = styled(motion.form)`
    display: flex;
    flex-direction: column;
    width: 100%;
`

export const InputFrom = styled(motion.input)`
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    letter-spacing: 1px;
    background-color: transparent;
    padding: 1.5rem 0.75rem;
    max-width: 100%;
    outline: none;
    margin-bottom: 2rem;
    border: 1px solid ${({theme}) => theme.colors.darkGreen};

    &:focus{
        border: 1px solid ${({theme}) => theme.colors.green}; 
    }
`
export const InputMessage = styled(motion.textarea)`
    color: ${({theme}) => theme.colors.textColor};
    letter-spacing: 1px;
    background-color: transparent;
    padding: 1.5rem 0.75rem;
    max-width: 100%;
    outline: none;
    margin-bottom: 2rem;
    border: 1px solid ${({theme}) => theme.colors.darkGreen};
    resize: none;

    &:focus{
        border: 1px solid ${({theme}) => theme.colors.green}; 
    }
`