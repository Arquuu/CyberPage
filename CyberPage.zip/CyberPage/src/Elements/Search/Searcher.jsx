import React from 'react'
import {AiOutlineSearch} from 'react-icons/ai'
import { SearchContainer, SearchInput, SearchIcon } from './StyledSearcher'
const Searcher = () => {
  return (
    <SearchContainer>
    <SearchInput type='text' placeholder='Search'/>
    <SearchIcon>
    <AiOutlineSearch />
    </SearchIcon>
    </SearchContainer>
  )
}

export default Searcher