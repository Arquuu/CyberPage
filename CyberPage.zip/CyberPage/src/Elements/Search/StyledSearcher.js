import styled from "styled-components";
import { motion } from "framer-motion";

export const SearchContainer = styled(motion.div)`
    width: 100%;
    display: flex;
    position: relative;
`
export const SearchInput = styled(motion.input)`
    width: 100%;
    padding: 1rem 1rem;
    background-color: transparent;
    border: 1px solid ${({theme}) => theme.colors.darkGreen};
    font-size: 1.1rem;
    letter-spacing: 1px;
    font-family: ${({theme}) => theme.font.secondFont};
    outline: none;
    color: ${({theme}) => theme.colors.textColor};
`
export const SearchIcon = styled(motion.div)`
    font-size: 1.5rem;
    color: ${({theme}) => theme.colors.darkGreen};
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: 10px;
    cursor: pointer;
`