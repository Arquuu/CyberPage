import styled from "styled-components";
import { motion } from "framer-motion";

export const ContactMapElement = styled(motion.div)`
    width: 100%;
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: flex-start;
`
export const ContactMapTop = styled(motion.div)`
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;

    ${({theme}) => theme.media.mobile}{
        flex-direction: column;
    }

`
export const ContactMapLeft = styled(motion.div)`
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start;
    padding-right: 1rem;
`
export const ContactMapRight = styled(motion.div)`
    width: 100%;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    align-items: flex-start;
    padding-right: 1rem;
`
export const ContactMapTitle = styled(motion.h1)`
    color: ${({theme}) => theme.colors.white};
`
export const ContactMapDescription = styled(motion.p)`
    color: ${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
    font-size: 1.1rem;
    padding-bottom: 1rem;
    line-height: 1.5;
`

export const Map = styled(motion.iframe)`
    display: flex;
    width: 100%;
    height: 100%;
    filter: grayscale(1);

    ${({theme}) => theme.media.tablet}{
        height: 500px;
    }
`