import Button from "./Button/Button";
import ButtonSecond from "./Button/ButtonSecond";
import Slider from "./Slider/Slider";
import HeadingSection from "./HeadingSection/HeadingSection";
import HeadingSectionCenter from "./HeadingSection/HeadingSectionCenter";
import MainPost from "./MainPost/MainPost";
import PostItem from "./PostItem/PostItem";
import PaginationButton from "./PaginationButton/PaginationButton";
import Searcher from "./Search/Searcher";
import Categories from "./Category/Categories";
import RecentPosts from "./RecentPosts/RecentPosts";
import PopularTags from "./PopularTags/PopularTags";
import ContactForm from "./ContactForm/ContactForm";
import ContactMap from "./ContactMap/ContactMap";

export{ 
    Button, 
    ButtonSecond, 
    Slider, 
    HeadingSection, 
    HeadingSectionCenter,
    MainPost,
    PostItem,
    PaginationButton,
    Searcher,
    Categories,
    RecentPosts,
    PopularTags,
    ContactForm,
    ContactMap
}