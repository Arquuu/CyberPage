import styled from "styled-components"
import { motion } from "framer-motion"

export const RecentPostsContainer = styled(motion.div)`
    width: 100%;
    display: flex;
    flex-direction: column;
    user-select: none;

`
export const TopContainer = styled(motion.div)`
    width: 100%;
    border-bottom: 1px solid ${({theme}) => theme.colors.darkGreen};
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    margin-bottom: 2rem;
`
export const Title = styled(motion.h1)`
    color: ${({theme}) => theme.colors.white};
    display: flex;
    position: relative;
    padding-bottom: 1rem;

    &::before{
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 80px;
        height: 2px;
        background-color: ${({theme}) => theme.colors.green};
    }
`
export const Icon = styled(motion.div)`
    display: flex;
    align-items: center;
    justify-content: center;
    color: ${({theme}) => theme.colors.white};
    font-size: 1.5rem;
    padding-bottom: 1rem;
`
export const ItemRecentPost = styled(motion.div)`
    width: 100%;
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 2rem;
    user-select: none;

    @media screen and (max-width: 1150px){
        flex-direction: column;
    }
    ${({theme}) => theme.media.mobile}{
        flex-direction: row;
        margin-bottom: 2rem;
    }
`

export const RecentImg = styled(motion.img)`
    max-width: 100px;
    max-height: 100px;
    width: 100%;
`

export const RecentContent = styled(motion.div)`
    width: 100%;
    display: flex;
    flex-direction: column;
    padding-left: 1rem;

    @media screen and (max-width: 1150px){
        padding: 1rem 0 0 0;
    }

    ${({theme}) => theme.media.mobile}{
        padding: 0 1rem 0 1rem;
    }
`

export const RecentTitle = styled(motion.h3)`
    color: ${({theme}) => theme.colors.white};
    cursor: pointer;
    transition: .4s;
    &:hover{
        color: ${({theme}) => theme.colors.green};

    }
`
export const RecentInfo = styled(motion.p)`
    padding: 1rem 0;
    font-size: .8rem;
    color:${({theme}) => theme.colors.textColor};
    font-family: ${({theme}) => theme.font.secondFont};
`
