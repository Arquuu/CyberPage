import React, { useState } from 'react'
import { AiOutlinePlus, AiOutlineMinus } from 'react-icons/ai'
import {TopContainer, Title, Icon, RecentPostsContainer, ItemRecentPost, RecentImg, RecentContent, RecentTitle, RecentInfo} from './StyledRecentPosts'
import { Blog1, Blog2, Blog3 } from '../../importImages'
const RecentPostsAll = [
  {
    id: 1,
    img: `${Blog1}`,
    title: 'Enior Apple Employee Alleges Sexism At',
    author: 'Arquuu',
    date: '20 Jun 2022'
  },
  {
    id: 2,
    img: `${Blog2}`,
    title: 'Enior Apple Employee Alleges Sexism At',
    author: 'Arquuu',
    date: '20 Jun 2022'
  },
  {
    id: 3,
    img: `${Blog3}`,
    title: 'Enior Apple Employee Alleges Sexism At',
    author: 'Arquuu',
    date: '20 Jun 2022'
  },

]




const RecentPosts = () => {

  const [active, setActive] = useState(true);
  return (
    <RecentPostsContainer>
      <TopContainer
      onClick={() => setActive(prevState => (!prevState))}>
        <Title>Recent Posts</Title>
        { active === true
         ? <Icon><AiOutlineMinus /></Icon>
         : <Icon><AiOutlinePlus /></Icon> 
        }
      </TopContainer>
        {active && (
          <>
          {RecentPostsAll.map((props) => (
          <ItemRecentPost>
          <RecentImg src={props.img} alt='' />
          <RecentContent>
            <RecentTitle>{props.title}</RecentTitle>
            <RecentInfo>by {props.author} | {props.date}</RecentInfo>
          </RecentContent>

        </ItemRecentPost>
          ))}
          </>
        )}

    </RecentPostsContainer>
  )
}


export default RecentPosts