import React, { useState } from 'react'
import { AiOutlinePlus, AiOutlineMinus } from 'react-icons/ai'
import { CategoriesContainer, TopContainer, Title, Icon, CategoriesList, CategoryItem } from './StyledCategories'

const ListCategories = [
  {
    id: 1,
    categoryName: 'Lastest',
    total: 22, 
  },
  {
    id: 2,
    categoryName: 'Analysis',
    total: 45, 
  },
  {
    id: 3,
    categoryName: 'Game',
    total: 99, 
  },
  {
    id: 4,
    categoryName: 'Digitalart',
    total: 53, 
  },
  {
    id: 5,
    categoryName: 'Mataverse',
    total: 63, 
  }
]


const Categories = () => {

  const [active, setActive] = useState(true);
  return (
    <CategoriesContainer>
      <TopContainer
      onClick={() => setActive(prevState => (!prevState))}>
        <Title>Categories</Title>
        { active === true
         ? <Icon><AiOutlineMinus /></Icon>
         : <Icon><AiOutlinePlus /></Icon> 
        }
      </TopContainer>
        {active && (
          <CategoriesList>
        {ListCategories.map((props) =>(
          <CategoryItem>{props.categoryName} ({props.total})</CategoryItem>
        ))}
        </CategoriesList>

        )}

      

    </CategoriesContainer>
  )
}

export default Categories