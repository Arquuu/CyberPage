import styled from "styled-components";
import { motion } from "framer-motion";

export const CategoriesContainer = styled(motion.div)`
    width: 100%;
    margin: 3rem 0;
    display: flex;
    flex-direction: column;
    user-select: none;
` 
export const TopContainer = styled(motion.div)`
    width: 100%;
    border-bottom: 1px solid ${({theme}) => theme.colors.darkGreen};
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
`
export const Title = styled(motion.h1)`
    color: ${({theme}) => theme.colors.white};
    display: flex;
    position: relative;
    padding-bottom: 1rem;

    &::before{
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        width: 80px;
        height: 2px;
        background-color: ${({theme}) => theme.colors.green};
    }
`
export const Icon = styled(motion.div)`
    display: flex;
    align-items: center;
    justify-content: center;
    color: ${({theme}) => theme.colors.white};
    font-size: 1.5rem;
    padding-bottom: 1rem;
    
`
export const CategoriesList = styled(motion.ul)`
    list-style: none;
    width: 100%;
    
`
export const CategoryItem = styled(motion.li)`
    color: ${({theme}) => theme.colors.white};
    margin: 1rem 0;
    font-size: 1.2rem;
    font-family: ${({theme}) => theme.font.secondFont};
    cursor: pointer;
    width: max-content;
    transition: .4s;
    &:hover{
        color: ${({theme}) => theme.colors.green};

    }
`